#!/usr/bin/Rscript
# _*_ coding: utf-8 _*_

library(optparse)
library("Seurat")
library("dplyr")
library("ggplot2")

#strp1
option_list <- list(
        	make_option(c("-i", "--input"), type = "character", default = FALSE, action = "store", help = "This is input file!"),
	make_option(c("-c", "--celltype"), type = "character", default = FALSE, action = "store", help = "This is cell type"),
        	make_option(c("-o", "--output"), type = "character", default = FALSE, action = "store", help = "This is output file!"))

#step2
opt_parse = OptionParser(usage = "usage: %prog [options]", option_list = option_list, add_help_option = TRUE, prog = NULL, description = "")

#step3
opt = parse_args(opt_parse)

#step4
inputfile = opt$input
celltype = opt$celltype
outdir = opt$output

singlecell.data <- readRDS(inputfile)

#markers <- FindMarkers(singlecell.data, only.pos = FALSE, min.pct = 0.25, logfc.threshold = 0.36, test.use = "wilcox", ident.1 = "SPG", ident.2 = "LC")

#markers <- FindMarkers(singlecell.data, only.pos = FALSE, min.pct = 0.25, logfc.threshold = 0.36, test.use = "wilcox", ident.1 = c("SPG", "ES"), ident.2 = "LC")

#markers <- FindMarkers(singlecell.data, only.pos = FALSE, min.pct = 0.25, logfc.threshold = 0.36, test.use = "wilcox", ident.1 = "epithelium cells")

#markers <- FindMarkers(singlecell.data, only.pos = FALSE, min.pct = 0.25, logfc.threshold = 0.36, test.use = "wilcox", ident.1 = "tumor-1", ident.2 = "normal-1", group.by = "Sample")

#markers <- FindMarkers(singlecell.data, only.pos = FALSE, min.pct = 0.25, logfc.threshold = 0.36, test.use = "wilcox", ident.1 = "tumor", ident.2 = "normal", group.by = "SampleGroup")

#markers <- FindMarkers(singlecell.data, only.pos = FALSE, min.pct = 0.25, logfc.threshold = 0.36, test.use = "wilcox", ident.1 = "case_1", ident.2 = "control_1", group.by = "Sample", subset.ident = "SPG")

markers <- FindMarkers(singlecell.data, only.pos = FALSE, min.pct = 0.25, logfc.threshold = 0.25, test.use = "wilcox", ident.1 = "Tumor", ident.2 = "Normal", group.by = "SampleGroup", subset.ident = celltype)

markers$change <- "NotSig"
markers$change[markers$p_val_adj < 0.05 & markers$avg_log2FC > 0.25] <- "Up"
markers$change[markers$p_val_adj < 0.05 & markers$avg_log2FC < -0.25] <- "Down"
up <- markers[markers$change=="Up",]
down <- markers[markers$change=="Down",]
nosig <- markers[markers$change=="NotSig",]

write.table(markers, file = paste0(outdir, "/DEG_all.txt"), sep = "\t", row.names = TRUE, quote = FALSE, col.names = NA)

write.table(up, file = paste0(outdir, "/DEG_up.txt"), sep = "\t", row.names = TRUE, quote = FALSE)

write.table(down, file = paste0(outdir, "/DEG_down.txt"), sep = "\t", row.names = TRUE, quote = FALSE)

write.table(nosig, file = paste0(outdir, "/DEG_notSig.txt"), sep = "\t", row.names = TRUE, quote = FALSE)

#DefaultAssay(singlecell.data) <- "RNA"
##FindAllMarkers
#all.markers <- FindAllMarkers(singlecell.data, only.pos = TRUE, min.pct = 0.25, logfc.threshold = 0.36, return.thresh = 0.01, test.use = "wilcox")
#top2diff <- all.markers %>% group_by(cluster) %>% slice_max(n = 2, order_by = avg_log2FC)
#topmarkers <- top2diff$gene
#topmarkers
#clusters <- unique(top2diff$cluster)
#DefaultAssay(singlecell.data) <- "integrated"
#DefaultAssay(singlecell.data) <- "RNA"

#for (clust in clusters) {
#        showgene <- "CAMK2D"
#        vlnplot <- VlnPlot(object = singlecell.data, features = showgene, ncol = 2)
#        pdf(paste0("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010030/advanced_analysis/DiffExp/MarkersPlot/", clust, ".TopMarkerGene_violin.pdf"), width=20, height=10)
#        print(vlnplot)
#        dev.off()
#        featureplot <- FeaturePlot(object = singlecell.data, features = showgene, ncol = 2, raster = FALSE)
#        pdf(paste0("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010030/advanced_analysis/DiffExp/MarkersPlot/", clust, ".TopMarkerGene_umap.pdf"), width=20, height=10)
#        print(featureplot)
#        dev.off()
#}