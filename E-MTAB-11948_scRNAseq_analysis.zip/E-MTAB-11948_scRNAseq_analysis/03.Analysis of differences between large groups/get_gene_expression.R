#!/usr/bin/Rscript
# _*_ coding: utf-8 _*_

library(optparse)
library("Seurat")
library("dplyr")

#strp1
option_list <- list(
        make_option(c("-i", "--input"), type = "character", default = FALSE, action = "store", help = "This is input file!"),
        make_option(c("-o", "--output"), type = "character", default = FALSE, action = "store", help = "This is output file!"))

#step2
opt_parse = OptionParser(usage = "usage: %prog [options]", option_list = option_list, add_help_option = TRUE, prog = NULL, description = "")

#step3
opt = parse_args(opt_parse)

#step4
inputfile = opt$input
outdir = opt$output

sce <- readRDS(inputfile)
sce@meta.data$celltype_orig.ident = paste0(sce@meta.data$celltype, "_", sce@meta.data$orig.ident)
Idents(sce) <- "celltype_orig.ident"
AverageExp <- AverageExpression(sce)
celltypes <- unique(sce@meta.data$celltype)
for(ct in celltypes){
	cols <- grep(paste0("^", ct, "_"), colnames(AverageExp))
	expr <- AverageExp[, cols]
	outfile <- paste0(outdir, "/", ct, "_expr_matrix.txt")
	write.table(expr, file = outfile, sep = "\t", quote = FALSE, col.names = NA)
}