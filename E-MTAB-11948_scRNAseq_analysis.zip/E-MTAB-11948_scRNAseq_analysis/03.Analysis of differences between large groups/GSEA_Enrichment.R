#!/usr/bin/Rscript
# _*_ coding: utf-8 _*_

library(optparse)
library(ggplot2)
library(stringr)
library(enrichplot)
library(clusterProfiler)
library(riceidconverter)

#strp1
option_list <- list(
        	make_option(c("-i", "--input"), type = "character", default = FALSE, action = "store", help = "This is input file!"),
	make_option(c("-d", "--OrgDb"), type = "character", default = FALSE, action = "store", help = "This is OrgDb species!"),
	make_option(c("-s", "--organism"), type = "character", default = FALSE, action = "store", help = "This is organism species!"),
	make_option(c("-g", "--genome"), type = "character", default = FALSE, action = "store", help = "This is Reference genome!"),
	make_option(c("-p", "--pvalue"), type = "double", default = FALSE, action = "store", help = "This is pvalue Cutoff"),
        	make_option(c("-o", "--outpath"), type = "character", default = FALSE, action = "store", help = "This is outpath!"))

#step2
opt_parse = OptionParser(usage = "usage: %prog [options]", option_list = option_list, add_help_option = TRUE, prog = NULL, description = "")

#step3
opt = parse_args(opt_parse)

#step4
inputfile = opt$input
outpath = opt$outpath
OrgDb_species = opt$OrgDb
organism_species = opt$organism
Reference_genome = opt$genome
pvalue = opt$pvalue
library(OrgDb_species,character.only = TRUE)

data <- read.table(file = inputfile, header = TRUE, sep = "\t", check.names = FALSE)

GO_database <- OrgDb_species #http://bioconductor.org/packages/release/BiocViews.html#___OrgDb
KEGG_database <- organism_species #http://www.genome.jp/kegg/catalog/org_list.html

database_name = strsplit(Reference_genome, "_")
if (grepl(database_name[[1]], "Ensembl")){
	gene <- bitr(data$Gene, fromType = 'ENSEMBL', toType = c('SYMBOL','ENTREZID'), OrgDb = GO_database)
	names(data) <- c('ENSEMBL','Log2FoldChange')
	df_merge <- merge(data, gene, by = 'ENSEMBL')
}else{
	gene <- bitr(data$Gene, fromType = 'SYMBOL', toType = 'ENTREZID', OrgDb = GO_database)
	names(data) <- c('SYMBOL','Log2FoldChange')
	df_merge <- merge(data, gene, by = 'SYMBOL')
}

GSEA_input <- df_merge$Log2FoldChange #numeric vector
names(GSEA_input) = as.character(df_merge$ENTREZID) #named vector
GSEA_input = sort(GSEA_input, decreasing = TRUE)
GSEA_GO <- gseGO(gene = GSEA_input,
	OrgDb = GO_database,
	keyType = "ENTREZID",
	ont = "ALL",
	pvalueCutoff = pvalue,
	pAdjustMethod = "BH",
	minGSSize = 1,
	maxGSSize = 1000)
GSEA_KEGG <- gseKEGG(geneList = GSEA_input, 
	organism = KEGG_database,
	pvalueCutoff = pvalue,
	pAdjustMethod = "BH",
	minGSSize = 1,
	maxGSSize = 1000)

GSEA_GO <- setReadable(GSEA_GO, OrgDb = OrgDb_species, keyType = "ENTREZID")
GSEA_KEGG <- setReadable(GSEA_KEGG, OrgDb = OrgDb_species, keyType = "ENTREZID")
gsea_go <- as.data.frame(GSEA_GO)
#table(gsea_go[,1])
gsea_kegg <- as.data.frame(GSEA_KEGG)
#table(gsea_kegg[,1])

mytheme <- theme(plot.title = element_text(size = 30, hjust = 0.5),
	panel.border = element_rect(color = "black", linewidth = 1, fill = NA),
	axis.text.x = element_text(size = 20),
	axis.text.y = element_text(size = 20),
	axis.title.x = element_text(size = 20),
	axis.title.y = element_text(size = 20),
	legend.title = element_text(size = 20),
	legend.text = element_text(size = 20),
	legend.key.height = unit(20, units = "mm"),
	axis.line = element_blank(),
	axis.ticks = element_line(linewidth = 1, colour = "gray30"),
	axis.ticks.length = unit(1.5, units = "mm"))

GSEA_GO_enrich <- gseaplot2(GSEA_GO, 1, title = "GSEA GO Enrichment")
GSEA_GO_enrich[[1]] <- GSEA_GO_enrich[[1]] + mytheme
GSEA_GO_enrich[[2]] <- GSEA_GO_enrich[[2]] + mytheme
GSEA_GO_enrich[[3]] <- GSEA_GO_enrich[[3]] + mytheme

GSEA_KEGG_enrich <- gseaplot2(GSEA_KEGG, 1, title = "GSEA KEGG Enrichment")
GSEA_KEGG_enrich[[1]] <- GSEA_KEGG_enrich[[1]] + mytheme
GSEA_KEGG_enrich[[2]] <- GSEA_KEGG_enrich[[2]] + mytheme
GSEA_KEGG_enrich[[3]] <- GSEA_KEGG_enrich[[3]] + mytheme

#GSEA_KEGG_enrich <- gseaplot2(GSEA_KEGG, geneSetID = "mmu04620", title = GSEA_KEGG$Description["Toll-like receptor signaling pathway - Mus musculus (house mouse)"], pvalue_table = T)
output_file1 <- file.path(outpath, "GSEA_GO_enrich")
output_file2 <- file.path(outpath, "GSEA_KEGG_enrich")

#print to png
png(paste0(output_file1, ".png"), width = 15, height = 12, units = "in", res = 300)
GSEA_GO_enrich
dev.off()
png(paste0(output_file2, ".png"), width = 15, height = 12, units = "in", res = 300)
GSEA_KEGG_enrich
dev.off()

#print to pdf
pdf(paste0(output_file1, ".pdf"), width = 15, height = 12)
GSEA_GO_enrich
dev.off()
pdf(paste0(output_file2, ".pdf"), width = 15, height = 12)
GSEA_KEGG_enrich
dev.off()

output_file3 <- file.path(outpath, "GSEA_GO_enrich.txt")
output_file4 <- file.path(outpath, "GSEA_KEGG_enrich.txt")
write.table(gsea_go, output_file3, sep = '\t', quote = FALSE, row.names = FALSE)
write.table(gsea_kegg, output_file4, sep = '\t', quote = FALSE, row.names = FALSE)