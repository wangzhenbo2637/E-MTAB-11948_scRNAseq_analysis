#!/usr/bin/Rscript
# _*_ coding: utf-8 _*_

library(optparse)

#strp1
option_list <- list(
        make_option(c("-i", "--input"), type = "character", default = FALSE, action = "store", help = "This is input file!"),
        make_option(c("-o", "--output"), type = "character", default = FALSE, action = "store", help = "This is output file!"))

#step2
opt_parse = OptionParser(usage = "usage: %prog [options]", option_list = option_list, add_help_option = TRUE, prog = NULL, description = "")

#step3
opt = parse_args(opt_parse)

#step4
inputfile = opt$input
outputfile = opt$output

df <- read.table(inputfile, header = TRUE, sep = "\t")
min_nonzero <- min(df$padj[df$padj > 0], na.rm = TRUE)
df$padj[df$padj == 0] <- min_nonzero
#df$minusLog10P <- -log10(df$pvalue)
df$minusLog10P <- -log10(df$padj)
write.table(df, file = outputfile, sep = "\t", quote = FALSE, row.names = FALSE)