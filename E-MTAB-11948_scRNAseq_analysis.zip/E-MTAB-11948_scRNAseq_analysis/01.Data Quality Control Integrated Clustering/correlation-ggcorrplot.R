library("corrplot")
data <- read.table("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/scRNA_Seq_Report/result/3.AllCellCluster/gene_mean_exp4clusters.xls", header = T, row.names = 1, check.names = F, sep = "\t")
dim(data)

corr <- round(cor(data, method = "pearson"), 4)
head(corr)
Samples <- row.names(corr)
outcorr <- cbind(Samples, corr)
write.table(outcorr, file = "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/AllClusters.correlation.xls", sep = "	", quote = F, row.names = F, col.names = T)

#col2 <- colorRampPalette(c("#67001F", "#B2182B", "#D6604D", "#F4A582", "#FDDBC7", "#FFFFFF", "#D1E5F0", "#92C5DE", "#4393C3", "#2166AC", "#053061"))

col3 <- colorRampPalette(c("#2192bc","#d74b4b"))

pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/AllClusters.CorrelationHeatmap.pdf",width=24,height=24,pointsize=15,onefile=FALSE)
corrplot.mixed(corr,
#	type = "upper", 
	upper = "circle", 
	lower.col = col3(200),
	diag = "l", 
	upper.col = col3(200),
	is.corr = F, 
	outline = F, 
	tl.pos = "lt", 
	tl.col = "black",
	#  cl.pos = "n", 
	#  cl.lim = c(0, 1),
	cl.length = 5,
	mar=c(0, 0, 1, 0),
	title = "Correlation between Clusters(method=pearson)" )
dev.off()