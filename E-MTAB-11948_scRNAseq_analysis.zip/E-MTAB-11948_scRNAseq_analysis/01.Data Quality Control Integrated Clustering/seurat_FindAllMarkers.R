library("Seurat")
library("dplyr")
library("ggplot2")

filtered.data <- readRDS("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/after_cluster_cells.rds")

DefaultAssay(filtered.data) <- "RNA"

##FindAllMarkers
all.markers <- FindAllMarkers(filtered.data, only.pos = TRUE, min.pct = 0.25, logfc.threshold = 0.36, return.thresh = 0.01, test.use = "wilcox")
write.table(all.markers, file = "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/DiffExpGene.xls", sep = "\t", row.names = T, quote = FALSE, col.names=NA)

top2diff <- all.markers %>% group_by(cluster) %>% slice_max(n = 2, order_by = avg_log2FC)
topmarkers <- top2diff$gene
topmarkers
clusters <- unique(top2diff$cluster)

DefaultAssay(filtered.data) <- "integrated"

pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/MarkersPlot/TopMarkerGene_heatmap.pdf", width=100, height=10)
DoHeatmap(object = filtered.data, features = topmarkers) + NoLegend()
dev.off()

DefaultAssay(filtered.data) <- "RNA"

pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/MarkersPlot/TopMarkerGene_dotplot.pdf", width=20, height=10)
DotPlot(object = filtered.data, features = unique(topmarkers))+theme(axis.text.x=element_text(angle=45,hjust=1))
dev.off()

for (clust in clusters) {
	showgene <- top2diff$gene[which(top2diff$cluster==clust)]
	vlnplot <- VlnPlot(object = filtered.data, features = showgene, ncol = 2)
	pdf(paste0("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/MarkersPlot/", clust, ".TopMarkerGene_violin.pdf"), width=20, height=10)
	print(vlnplot)
	dev.off()
	featureplot <- FeaturePlot(object = filtered.data, features = showgene, ncol = 2, raster = FALSE)
	pdf(paste0("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/MarkersPlot/", clust, ".TopMarkerGene_umap.pdf"), width=20, height=10)
	print(featureplot)
	dev.off()
}