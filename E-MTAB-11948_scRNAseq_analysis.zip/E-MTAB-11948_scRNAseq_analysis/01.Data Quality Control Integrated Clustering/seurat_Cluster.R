library("Seurat")
library("ggplot2")
library("cowplot")
library("dplyr")
library("patchwork")

filtered.data <- readRDS("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/after_filter_cells.rds")

##process data:NormalizeData/FindVariableFeatures/ScaleData/RunPCA/JackStraw/FindNeighbors##

DefaultAssay(filtered.data) <- "integrated"

filtered.data <- ScaleData(object = filtered.data, verbose = FALSE)

#remove unwanted sources of variation, use SCTransform instead ScaleData#
#filtered.data <- SCTransform(filtered.data, vars.to.regress = "percent.mito", verbose = FALSE)

filtered.data <- RunPCA(object = filtered.data, npcs = 30, verbose = FALSE)

#Examine and visualize PCA results a few different ways#
print(filtered.data[["pca"]], dims = 1:5, nfeatures = 5)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/pca_VizDimLoadings.pdf", width=12, height=10)
VizDimLoadings(filtered.data, dims = 1:2, reduction = "pca")
dev.off()
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/pca_DimPlot.pdf", width=12, height=10)
DimPlot(filtered.data, reduction = "pca")
dev.off()
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/pca_DimHeatmap.pdf", width=10, height=20)
DimHeatmap(filtered.data, dims = 1:20, cells = 500, balanced = TRUE)
dev.off()

filtered.data <- JackStraw(filtered.data, num.replicate = 100)
filtered.data <- ScoreJackStraw(filtered.data, dims = 1:20)

pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/pca_JackStrawPlot.pdf", width=10, height=15)
JackStrawPlot(filtered.data, dims = 1:20)
dev.off()
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/pca_ElbowPlot.pdf", width=10, height=15)
ElbowPlot(filtered.data)
dev.off()

##cell cluster
filtered.data <- FindNeighbors(filtered.data, reduction = "pca", dims = 1:20)
filtered.data <- FindClusters(filtered.data, resolution = 0.2)
write.table(filtered.data@meta.data, file = "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/cell2cluster.xls", quote=FALSE, sep = "\t", col.names=NA)
write.table(table(filtered.data$seurat_clusters), file = "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/cluster_cellnumber.xls", quote=FALSE, sep = "\t", col.names=NA)

##RunUMAP
filtered.data <- RunUMAP(filtered.data, reduction = "pca", umap.method = "uwot", dims = 1:20)
filtered.data <- RunTSNE(filtered.data, reduction = "pca", dims = 1:20)

saveRDS(filtered.data, file = "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/after_cluster_cells.rds")

sample.1.sub <- subset(filtered.data, subset = Sample == "Tumor_3")
sample.1.p1 <- DimPlot(object = sample.1.sub, reduction = "umap", group.by = "Sample")
sample.1.p2 <- DimPlot(object = sample.1.sub, reduction = "umap", label = TRUE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/umap_cluster.Tumor_3.pdf", width=22, height=10)
print(sample.1.p1 + sample.1.p2)
dev.off()

sample.1.p1 <- DimPlot(object = sample.1.sub, reduction = "tsne", group.by = "Sample")
sample.1.p2 <- DimPlot(object = sample.1.sub, reduction = "tsne", label = TRUE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/tsne_cluster.Tumor_3.pdf", width=22, height=10)
print(sample.1.p1 + sample.1.p2)
dev.off()
rm(sample.1.sub)

sample.2.sub <- subset(filtered.data, subset = Sample == "Tumor_1")
sample.2.p1 <- DimPlot(object = sample.2.sub, reduction = "umap", group.by = "Sample")
sample.2.p2 <- DimPlot(object = sample.2.sub, reduction = "umap", label = TRUE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/umap_cluster.Tumor_1.pdf", width=22, height=10)
print(sample.2.p1 + sample.2.p2)
dev.off()

sample.2.p1 <- DimPlot(object = sample.2.sub, reduction = "tsne", group.by = "Sample")
sample.2.p2 <- DimPlot(object = sample.2.sub, reduction = "tsne", label = TRUE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/tsne_cluster.Tumor_1.pdf", width=22, height=10)
print(sample.2.p1 + sample.2.p2)
dev.off()
rm(sample.2.sub)

sample.3.sub <- subset(filtered.data, subset = Sample == "Normal_2")
sample.3.p1 <- DimPlot(object = sample.3.sub, reduction = "umap", group.by = "Sample")
sample.3.p2 <- DimPlot(object = sample.3.sub, reduction = "umap", label = TRUE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/umap_cluster.Normal_2.pdf", width=22, height=10)
print(sample.3.p1 + sample.3.p2)
dev.off()

sample.3.p1 <- DimPlot(object = sample.3.sub, reduction = "tsne", group.by = "Sample")
sample.3.p2 <- DimPlot(object = sample.3.sub, reduction = "tsne", label = TRUE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/tsne_cluster.Normal_2.pdf", width=22, height=10)
print(sample.3.p1 + sample.3.p2)
dev.off()
rm(sample.3.sub)

sample.4.sub <- subset(filtered.data, subset = Sample == "Tumor_2")
sample.4.p1 <- DimPlot(object = sample.4.sub, reduction = "umap", group.by = "Sample")
sample.4.p2 <- DimPlot(object = sample.4.sub, reduction = "umap", label = TRUE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/umap_cluster.Tumor_2.pdf", width=22, height=10)
print(sample.4.p1 + sample.4.p2)
dev.off()

sample.4.p1 <- DimPlot(object = sample.4.sub, reduction = "tsne", group.by = "Sample")
sample.4.p2 <- DimPlot(object = sample.4.sub, reduction = "tsne", label = TRUE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/tsne_cluster.Tumor_2.pdf", width=22, height=10)
print(sample.4.p1 + sample.4.p2)
dev.off()
rm(sample.4.sub)

sample.5.sub <- subset(filtered.data, subset = Sample == "Normal_3")
sample.5.p1 <- DimPlot(object = sample.5.sub, reduction = "umap", group.by = "Sample")
sample.5.p2 <- DimPlot(object = sample.5.sub, reduction = "umap", label = TRUE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/umap_cluster.Normal_3.pdf", width=22, height=10)
print(sample.5.p1 + sample.5.p2)
dev.off()

sample.5.p1 <- DimPlot(object = sample.5.sub, reduction = "tsne", group.by = "Sample")
sample.5.p2 <- DimPlot(object = sample.5.sub, reduction = "tsne", label = TRUE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/tsne_cluster.Normal_3.pdf", width=22, height=10)
print(sample.5.p1 + sample.5.p2)
dev.off()
rm(sample.5.sub)

sample.6.sub <- subset(filtered.data, subset = Sample == "Normal_1")
sample.6.p1 <- DimPlot(object = sample.6.sub, reduction = "umap", group.by = "Sample")
sample.6.p2 <- DimPlot(object = sample.6.sub, reduction = "umap", label = TRUE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/umap_cluster.Normal_1.pdf", width=22, height=10)
print(sample.6.p1 + sample.6.p2)
dev.off()

sample.6.p1 <- DimPlot(object = sample.6.sub, reduction = "tsne", group.by = "Sample")
sample.6.p2 <- DimPlot(object = sample.6.sub, reduction = "tsne", label = TRUE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/tsne_cluster.Normal_1.pdf", width=22, height=10)
print(sample.6.p1 + sample.6.p2)
dev.off()
rm(sample.6.sub)

p1 <- DimPlot(object = filtered.data, reduction = "umap", group.by = "Sample", raster = FALSE)
p2 <- DimPlot(object = filtered.data, reduction = "umap", label = TRUE, raster = FALSE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/umap_cluster.pdf", width=22, height=10)
print(p1 + p2)
dev.off()

pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/umap_cluster_splitBySample.pdf", width=62, height=10)
DimPlot(object = filtered.data, reduction = "umap", split.by = "Sample", raster = FALSE)
dev.off()

p1 <- DimPlot(object = filtered.data, reduction = "tsne", group.by = "Sample", raster = FALSE)
p2 <- DimPlot(object = filtered.data, reduction = "tsne", label = TRUE, raster = FALSE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/tsne_cluster.pdf", width=22, height=10)
print(p1 + p2)
dev.off()

pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/tsne_cluster_splitBySample.pdf", width=62, height=10)
DimPlot(object = filtered.data, reduction = "tsne", split.by = "Sample", raster = FALSE)
dev.off()

DefaultAssay(filtered.data) <- "RNA"