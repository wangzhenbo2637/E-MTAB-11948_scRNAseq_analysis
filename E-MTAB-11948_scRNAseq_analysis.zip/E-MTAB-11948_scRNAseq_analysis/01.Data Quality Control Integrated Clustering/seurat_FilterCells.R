library("Seurat")
library("ggplot2")
library("cowplot")

##filter cells
singlecells.data <- readRDS("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/before_filter_cells.rds")
singlecells.data
DefaultAssay(singlecells.data) <- "RNA"
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/nUMI-nGene.pdf")
FeatureScatter(object = singlecells.data, feature1 = "nCount_RNA", feature2 = "nFeature_RNA")
dev.off()
singlecells.data[["percent.mito"]] <- PercentageFeatureSet(singlecells.data, pattern = "^MT.")
filtered.data <- subset(singlecells.data, subset = nFeature_RNA > 200 & nFeature_RNA < 4500 & percent.mito < 25)
filtered.data
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/afterFilter.nUMI-nGene.pdf")
FeatureScatter(object = filtered.data, feature1 = "nCount_RNA", feature2 = "nFeature_RNA")
dev.off()

#write.table(singlecells.data[["RNA"]]@counts, file = "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/allcells_geneexp.xls", quote=FALSE, sep = "\t", col.names=NA)
#write.table(filtered.data[["RNA"]]@counts, file = "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/afterFilter.allcells_geneexp.xls", quote=FALSE, sep = "\t", col.names=NA)
saveRDS(filtered.data, file = "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/after_filter_cells.rds")
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/GeneUMI.violin.pdf")
VlnPlot(object = singlecells.data, features = c("nFeature_RNA", "nCount_RNA", "percent.mito"), ncol = 3)
dev.off()

pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/afterFilter.GeneUMI.violin.pdf")
VlnPlot(object = filtered.data, features = c("nFeature_RNA", "nCount_RNA", "percent.mito"), ncol = 3)
dev.off()

pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/nUMI-pMito.pdf")
FeatureScatter(object = singlecells.data, feature1 = "nCount_RNA", feature2 = "percent.mito")
dev.off()

pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/afterFilter.nUMI-pMito.pdf")
FeatureScatter(object = filtered.data, feature1 = "nCount_RNA", feature2 = "percent.mito")
dev.off()