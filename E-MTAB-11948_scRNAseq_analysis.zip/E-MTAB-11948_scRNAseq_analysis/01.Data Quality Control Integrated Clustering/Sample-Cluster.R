library("ggplot2")
library("dplyr")

data <- read.table("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/Sample-Cluster.CellNumber.4barplot", header = TRUE, check.names = FALSE, sep = "\t")

#data$Cluster <- factor(data$Cluster, levels = rev(unique(data$Cluster)))
data$Cluster <- factor(data$Cluster, levels = unique(data$Cluster))

pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/Sample-Cluster.CellNumber.pdf")
ggplot(data, aes(x=Sample, y=CellNumber, fill=Cluster)) + 
  geom_bar(stat = "identity", position = "stack", width = 0.75) + 
  labs(title="Number of Cells in Samples", x="Samples", y="Number of Cells") + 
  scale_fill_discrete(name = "Cluster") + 
#  coord_flip(expand = T) + 
  theme(axis.line = element_line(colour = "black"),
        plot.title = element_text(hjust = 0.5),
        panel.grid.major = element_line(colour = "gray"),
        panel.grid.minor = element_blank(),
        panel.grid.major.x = element_blank(),
        panel.border = element_rect(fill='transparent',color='black'),
        panel.background = element_rect(fill='transparent', color='grey50'),
        axis.text.x = element_text(size=10,angle=45,hjust=1,vjust=1))
dev.off()

data <- read.table("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/Sample-Cluster.CellFraction.4barplot", header = TRUE, check.names = FALSE, sep = "\t")

#data$Cluster <- factor(data$Cluster, levels = rev(unique(data$Cluster)))
data$Cluster <- factor(data$Cluster, levels = unique(data$Cluster))

pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/Sample-Cluster.CellFraction.pdf")
ggplot(data, aes(x=Sample, y=CellFraction, fill=Cluster)) + 
  geom_bar(stat = "identity", position = "stack", width = 0.75) + 
  labs(title="Fraction of Cells in Samples", x="Samples", y="Fraction of Cells") + 
  scale_fill_discrete(name = "Cluster") + 
#  coord_flip(expand = T) + 
  theme(axis.line = element_line(colour = "black"),
        plot.title = element_text(hjust = 0.5),
        panel.grid.major = element_line(colour = "gray"),
        panel.grid.minor = element_blank(),
        panel.grid.major.x = element_blank(),
        panel.border = element_rect(fill='transparent',color='black'),
        panel.background = element_rect(fill='transparent', color='grey50'),
        axis.text.x = element_text(size=10,angle=45,hjust=1,vjust=1))
dev.off()