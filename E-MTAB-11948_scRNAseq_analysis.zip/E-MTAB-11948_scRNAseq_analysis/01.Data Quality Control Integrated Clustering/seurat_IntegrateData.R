library("Seurat")
library("patchwork")

sample.1.data <- Read10X(data.dir = "/data/share03/NGS_Seq/10xgenomics/26HCF010036/Normal_1/")
dim(sample.1.data)
sample.1 <- CreateSeuratObject(counts = sample.1.data, project = "Normal_1", min.cells = 3)
sample.1$Sample <- "Normal_1"
sample.1 <- NormalizeData(sample.1, verbose = FALSE)
sample.1 <- FindVariableFeatures(sample.1, selection.method = "vst", nfeatures = 2000)

# Identify the 10 most highly variable genes
top10.sample.1 <- head(VariableFeatures(sample.1), 10)

# plot variable features with and without labels
plot1 <- VariableFeaturePlot(sample.1)
plot2 <- LabelPoints(plot = plot1, points = top10.sample.1, repel = TRUE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/VariableFeaturePlot_Normal_1.pdf", width=18, height=10)
print(plot1 + plot2)
dev.off()
sample.2.data <- Read10X(data.dir = "/data/share03/NGS_Seq/10xgenomics/26HCF010036/Normal_2/")
dim(sample.2.data)
sample.2 <- CreateSeuratObject(counts = sample.2.data, project = "Normal_2", min.cells = 3)
sample.2$Sample <- "Normal_2"
sample.2 <- NormalizeData(sample.2, verbose = FALSE)
sample.2 <- FindVariableFeatures(sample.2, selection.method = "vst", nfeatures = 2000)

# Identify the 10 most highly variable genes
top10.sample.2 <- head(VariableFeatures(sample.2), 10)

# plot variable features with and without labels
plot1 <- VariableFeaturePlot(sample.2)
plot2 <- LabelPoints(plot = plot1, points = top10.sample.2, repel = TRUE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/VariableFeaturePlot_Normal_2.pdf", width=18, height=10)
print(plot1 + plot2)
dev.off()
sample.3.data <- Read10X(data.dir = "/data/share03/NGS_Seq/10xgenomics/26HCF010036/Normal_3/")
dim(sample.3.data)
sample.3 <- CreateSeuratObject(counts = sample.3.data, project = "Normal_3", min.cells = 3)
sample.3$Sample <- "Normal_3"
sample.3 <- NormalizeData(sample.3, verbose = FALSE)
sample.3 <- FindVariableFeatures(sample.3, selection.method = "vst", nfeatures = 2000)

# Identify the 10 most highly variable genes
top10.sample.3 <- head(VariableFeatures(sample.3), 10)

# plot variable features with and without labels
plot1 <- VariableFeaturePlot(sample.3)
plot2 <- LabelPoints(plot = plot1, points = top10.sample.3, repel = TRUE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/VariableFeaturePlot_Normal_3.pdf", width=18, height=10)
print(plot1 + plot2)
dev.off()
sample.4.data <- Read10X(data.dir = "/data/share03/NGS_Seq/10xgenomics/26HCF010036/Tumor_1/")
dim(sample.4.data)
sample.4 <- CreateSeuratObject(counts = sample.4.data, project = "Tumor_1", min.cells = 3)
sample.4$Sample <- "Tumor_1"
sample.4 <- NormalizeData(sample.4, verbose = FALSE)
sample.4 <- FindVariableFeatures(sample.4, selection.method = "vst", nfeatures = 2000)

# Identify the 10 most highly variable genes
top10.sample.4 <- head(VariableFeatures(sample.4), 10)

# plot variable features with and without labels
plot1 <- VariableFeaturePlot(sample.4)
plot2 <- LabelPoints(plot = plot1, points = top10.sample.4, repel = TRUE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/VariableFeaturePlot_Tumor_1.pdf", width=18, height=10)
print(plot1 + plot2)
dev.off()
sample.5.data <- Read10X(data.dir = "/data/share03/NGS_Seq/10xgenomics/26HCF010036/Tumor_2/")
dim(sample.5.data)
sample.5 <- CreateSeuratObject(counts = sample.5.data, project = "Tumor_2", min.cells = 3)
sample.5$Sample <- "Tumor_2"
sample.5 <- NormalizeData(sample.5, verbose = FALSE)
sample.5 <- FindVariableFeatures(sample.5, selection.method = "vst", nfeatures = 2000)

# Identify the 10 most highly variable genes
top10.sample.5 <- head(VariableFeatures(sample.5), 10)

# plot variable features with and without labels
plot1 <- VariableFeaturePlot(sample.5)
plot2 <- LabelPoints(plot = plot1, points = top10.sample.5, repel = TRUE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/VariableFeaturePlot_Tumor_2.pdf", width=18, height=10)
print(plot1 + plot2)
dev.off()
sample.6.data <- Read10X(data.dir = "/data/share03/NGS_Seq/10xgenomics/26HCF010036/Tumor_3/")
dim(sample.6.data)
sample.6 <- CreateSeuratObject(counts = sample.6.data, project = "Tumor_3", min.cells = 3)
sample.6$Sample <- "Tumor_3"
sample.6 <- NormalizeData(sample.6, verbose = FALSE)
sample.6 <- FindVariableFeatures(sample.6, selection.method = "vst", nfeatures = 2000)

# Identify the 10 most highly variable genes
top10.sample.6 <- head(VariableFeatures(sample.6), 10)

# plot variable features with and without labels
plot1 <- VariableFeaturePlot(sample.6)
plot2 <- LabelPoints(plot = plot1, points = top10.sample.6, repel = TRUE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/VariableFeaturePlot_Tumor_3.pdf", width=18, height=10)
print(plot1 + plot2)
dev.off()
features <- SelectIntegrationFeatures(object.list = list(sample.1,sample.2,sample.3,sample.4,sample.5,sample.6))
all.anchors <- FindIntegrationAnchors(object.list = list(sample.1,sample.2,sample.3,sample.4,sample.5,sample.6), anchor.features = features)
singlecells.data <- IntegrateData(anchorset = all.anchors)
DefaultAssay(singlecells.data) <- "integrated"
saveRDS(singlecells.data, file = "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/before_filter_cells.rds")