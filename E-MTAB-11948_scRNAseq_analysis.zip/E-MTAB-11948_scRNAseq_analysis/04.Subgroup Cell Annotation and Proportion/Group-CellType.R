#!/usr/bin/Rscript
# _*_ coding: utf-8 _*_

library(optparse)
#library(readxl)
library(ggplot2)
library(tidyr)
library(reshape2)
rm(list=ls())

#strp1
option_list <- list(
        make_option(c("-i", "--input"), type = "character", default = FALSE, action = "store", help = "This is input file!"),
        make_option(c("-o", "--output"), type = "character", default = FALSE, action = "store", help = "This is output file!"))

#step2
opt_parse = OptionParser(usage = "usage: %prog [options]", option_list = option_list, add_help_option = TRUE, prog = NULL, description = "")

#step3
opt = parse_args(opt_parse)

#step4
inputfile = opt$input
outdir = opt$output

test <- read.table(inputfile, sep = "\t", header = TRUE, check.names = FALSE)
ra.melt <- melt(test, id.vars = "group",variable.name = "CellType",value.name = "Proportion")

colors_18 <- c('#4b6aa8','#3ca0cf','#c376a7','#ad98c3','#cea5c7','#53738c','#a5a9b0','#a78982','#696a6c','#92699e','#d69971','#df5734','#6c408e','#ac6894','#d4c2db','#537eb7','#83ab8e','#ece399')

p <- ggplot(ra.melt, aes(x = group, y = Proportion, fill = CellType))
theme = theme(panel.grid = element_blank()) +  
  theme(panel.border = element_blank(),panel.background = element_blank()) +  
  theme(axis.line = element_line(size=0.8, colour = "black")) 
p = p + theme + geom_bar(aes(fill = CellType), stat = "identity", position = "fill") + 
  labs(x = "Group", y = "Proportion of celltype")+
  scale_fill_manual(values = colors_18)+
  theme(title=element_text(size=12,color="black"),
        axis.title.x=element_text(size=14,color="black"),
        axis.title.y=element_text(size=14,color="black"),
        axis.text.x=element_text(size=12,color="black",angle = 45,hjust = 1),
        axis.text.y=element_text(size=12,color="black"))+
  theme(axis.text.x = element_text(angle = 45,vjust = 0.5,hjust = 0.5),
        axis.title = element_text(size = 11, color = "black"),
        axis.text = element_text(size = 9, color = "black"),
        legend.title = element_text(size=13,color="black"),
        legend.text= element_text(size=11,color="black"))

ggsave(paste0(outdir, "Group-CellType.CellFraction.pdf"), plot = p, width = 180, height = 120, units = "mm")
ggsave(paste0(outdir, "Group-CellType.CellFraction.png"), plot = p, width = 180, height = 120, units = "mm")