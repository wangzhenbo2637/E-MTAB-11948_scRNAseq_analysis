#UMAP_celltype UMAP_celltype_Group
/data/share03/Software/R-4.4.1/bin/Rscript ./scripts/UMAP_plot.R -i /data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/SubCluster/CellTypeIdent/Epithelial_cells/after_RenameIdents.rds -o /data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/SubCluster/CellTypeIdent/

#Group-CellType.CellFraction
/data/share03/Software/R-4.4.1/bin/Rscript ./scripts/Group-CellType.R -i /data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/SubCluster/CellTypeIdent/CellNumber.CellType-Group.xls -o /data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/SubCluster/CellTypeIdent/

#MarkerGene_dotplot_celltype
/data/share03/Software/R-4.4.1/bin/Rscript ./scripts/seurat_FindAllMarkers.R -i /data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/SubCluster/CellTypeIdent/Epithelial_cells/after_RenameIdents.rds -o /data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/SubCluster/CellTypeIdent/

#TopMarkerGene_dotplot
/data/share03/Software/R-4.4.1/bin/Rscript ./scripts/DotPlot.R -i /data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/SubCluster/CellTypeIdent/Epithelial_cells/after_RenameIdents.rds -g "SPRR1B,S100A8,PI3,IER5,SOX4,IER5L,UBE2C,TOP2A,CDK1,SCGB3A1,TFF3,MUC5B,COL1A1,COL1A2,COL3A1,KRT15,COL17A1,DST,HLA-DRA,HLA-DRB1,CD74" -o /data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/SubCluster/CellTypeIdent/

#Fig_OR.all_cell.OR.dist
/data/share03/Software/R-4.4.1/bin/Rscript ./scripts/seurat_obj_meta.R -i /data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/SubCluster/CellTypeIdent/Epithelial_cells/after_RenameIdents.rds -o /data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/SubCluster/CellTypeIdent/

#/data/share03/Software/R-4.4.1/bin/Rscript ./scripts/OR_valuea_analysis.R