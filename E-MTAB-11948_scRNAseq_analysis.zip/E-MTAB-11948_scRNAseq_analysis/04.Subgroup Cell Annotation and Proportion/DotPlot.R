#!/usr/bin/Rscript
# _*_ coding: utf-8 _*_

library(optparse)
library("Seurat")
library("ggplot2")
library("dplyr")
library("cowplot")
library("patchwork")

#strp1
option_list <- list(
        	make_option(c("-i", "--input"), type = "character", default = FALSE, action = "store", help = "This is input file!"),
	make_option(c("-g", "--genes"), type = "character", default = FALSE, action = "store", help = "This is marker gene list"),
        	make_option(c("-o", "--output"), type = "character", default = FALSE, action = "store", help = "This is output file!"))

#step2
opt_parse = OptionParser(usage = "usage: %prog [options]", option_list = option_list, add_help_option = TRUE, prog = NULL, description = "")

#step3
opt = parse_args(opt_parse)

#step4
inputfile = opt$input
cluster_marker = strsplit(opt$genes, ",")[[1]]
outdir = opt$output

singlecell.data <- readRDS(inputfile)

#P1 = DotPlot(object = singlecell.data, features = unique(cluster_marker),group = "celltype")+
#  scale_color_gradientn(colours = c('#330066','#336699','#66CC66','#FFCC33'))+
#  theme(axis.text.x = element_text(angle = 45,vjust = 0.5,hjust = 0.5),
#        axis.title = element_text(size = 11, color = "black"),
#        axis.text = element_text(size = 9, color = "black"),
#        legend.text = element_text(size = 8, color = "black"),
#        legend.title = element_text(size = 9, color = "black"))

#ggsave(paste0(dir,"celltype_markerBubble.pdf"), plot = P1, width = 440, height = 120, units = "mm")
#ggsave(paste0(dir,"celltype_markerBubble.png"), plot = P1, width = 440, height = 120, units = "mm")

#marker gene
P1 = DotPlot(object = singlecell.data, features = unique(cluster_marker),group = "celltype")+
  scale_color_gradientn(colours = c('#330066','#336699','#66CC66','#FFCC33'))+
  theme(axis.text.x = element_text(angle = 45,vjust = 0.5,hjust = 0.5),
        axis.title = element_text(size = 14, color = "black"),
        axis.text = element_text(size = 12, color = "black"),
        legend.text = element_text(size = 11, color = "black"),
        legend.title = element_text(size = 13, color = "black"))

ggsave(paste0(outdir,"MarkerGene_dotplot_celltype.pdf"), plot = P1, width = 440, height = 120, units = "mm")
ggsave(paste0(outdir,"MarkerGene_dotplot_celltype.png"), plot = P1, width = 440, height = 120, units = "mm")