#!/usr/bin/Rscript
# _*_ coding: utf-8 _*_

library(optparse)
library("Seurat")
library("ggplot2")
library("dplyr")
library("cowplot")
library("patchwork")

#strp1
option_list <- list(
        make_option(c("-i", "--input"), type = "character", default = FALSE, action = "store", help = "This is input file!"),
        make_option(c("-o", "--output"), type = "character", default = FALSE, action = "store", help = "This is output file!"))

#step2
opt_parse = OptionParser(usage = "usage: %prog [options]", option_list = option_list, add_help_option = TRUE, prog = NULL, description = "")

#step3
opt = parse_args(opt_parse)

#step4
inputfile = opt$input
outdir = opt$output

singlecell.data <- readRDS(inputfile)

colors_18 <- c('#4b6aa8','#3ca0cf','#c376a7','#ad98c3','#cea5c7','#53738c','#a5a9b0','#a78982','#696a6c','#92699e','#d69971','#df5734','#6c408e','#ac6894','#d4c2db','#537eb7','#83ab8e','#ece399')

P1 = UMAPPlot(object = singlecell.data, pt.size = 0.5, label = FALSE, group = "celltype", cols = colors_18)+
	theme(axis.title = element_text(size = 11, color = "black"),
	axis.text = element_text(size = 9, color = "black"),
	legend.text = element_text(size = 8, color = "black"),
	legend.title = element_text(size = 9, color = "black"))

ggsave(paste0(outdir,"UMAP_celltype.pdf"), plot = P1, width = 190, height = 120, units = "mm")
ggsave(paste0(outdir,"UMAP_celltype.png"), plot = P1, width = 190, height = 120, units = "mm")

P2 = UMAPPlot(object = singlecell.data, pt.size = 0.5, label = FALSE, group = "SampleGroup", cols = colors_18)+
	theme(axis.title = element_text(size = 11, color = "black"),
	axis.text = element_text(size = 9, color = "black"),
	legend.text = element_text(size = 8, color = "black"),
	legend.title = element_text(size = 9, color = "black"))

ggsave(paste0(outdir,"UMAP_celltype_Group.pdf"), plot = P2, width = 190, height = 120, units = "mm")
ggsave(paste0(outdir,"UMAP_celltype_Group.png"), plot = P2, width = 190, height = 120, units = "mm")