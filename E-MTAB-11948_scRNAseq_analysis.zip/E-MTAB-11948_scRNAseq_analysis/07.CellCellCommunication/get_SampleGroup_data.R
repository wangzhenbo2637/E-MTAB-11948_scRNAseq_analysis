library("Seurat")

seurat_object <- readRDS("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/SubCluster/CellTypeIdent/Epithelial_cells/after_RenameIdents.rds")
colnames(seurat_object@meta.data)
unique(seurat_object$SampleGroup)
table(seurat_object$SampleGroup)

tumor_obj <- subset(seurat_object,subset = SampleGroup == "Tumor")
normal_obj <- subset(seurat_object,subset = SampleGroup == "Normal")
saveRDS(tumor_obj, file = "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/tumor.rds")
saveRDS(normal_obj, file = "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/normal.rds")
