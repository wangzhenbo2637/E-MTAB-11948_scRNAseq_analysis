rm(list = ls())
library(CellChat)
library(patchwork)

cellchat_normal <- readRDS("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/normal.rds")
cellchat_tumor <- readRDS("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/tumor.rds")
colnames(cellchat_normal@meta.data)
cellchat_normal <- createCellChat(object = cellchat_normal,group.by = "celltype")
cellchat_tumor <- createCellChat(object = cellchat_tumor,group.by = "celltype")

cellchat_normal@DB <- CellChatDB.human
cellchat_tumor@DB <- CellChatDB.human

cellchat_normal <- subsetData(cellchat_normal)
cellchat_normal <- identifyOverExpressedGenes(cellchat_normal)
cellchat_normal <- identifyOverExpressedInteractions(cellchat_normal)

cellchat_tumor <- subsetData(cellchat_tumor)
cellchat_tumor <- identifyOverExpressedGenes(cellchat_tumor)
cellchat_tumor <- identifyOverExpressedInteractions(cellchat_tumor)

cellchat_normal <- computeCommunProb(cellchat_normal)
cellchat_normal <- filterCommunication(cellchat_normal, min.cells = 10)
cellchat_normal <- computeCommunProbPathway(cellchat_normal)
cellchat_normal <- aggregateNet(cellchat_normal)

cellchat_tumor <- computeCommunProb(cellchat_tumor)
cellchat_tumor <- filterCommunication(cellchat_tumor, min.cells = 10)
cellchat_tumor <- computeCommunProbPathway(cellchat_tumor)
cellchat_tumor <- aggregateNet(cellchat_tumor)

#cellchat_SN <- updateCellChat(cellchat_SN)
cellchat_normal <- netAnalysis_computeCentrality(cellchat_normal, slot.name = "netP")
#cellchat_SP <- updateCellChat(cellchat_SP)
cellchat_tumor <- netAnalysis_computeCentrality(cellchat_tumor, slot.name = "netP")
object.list <- list(normal = cellchat_normal, tumor = cellchat_tumor)
cellchat <- mergeCellChat(object.list, add.names = names(object.list))
#> Merge the following slots: 'data.signaling','net', 'netP','meta', 'idents', 'var.features' , 'DB', and 'LR'.
cellchat

p1 <- compareInteractions(cellchat, show.legend = FALSE, group = c(1, 2))
p2 <- compareInteractions(cellchat, show.legend = FALSE, group = c(1, 2), measure = "weight")
p3 <- p1 + p2

output_file <- "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/cellchat_Interactions."
ggsave(paste0(output_file, ".png"), plot = p3, width = 120, height = 100, units = "mm", dpi = 300)
ggsave(paste0(output_file, ".pdf"), plot = p3, width = 120, height = 100, units = "mm")

#pdf(file="/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/cellchat_Interactions_2.pdf", width = 10, height = 12)
#p1 + p2
#dev.off()

pdf(file="/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/cellchat_netVisual_diffInteraction_2.pdf",width = 10,height = 12)
netVisual_diffInteraction(cellchat, weight.scale = T)
netVisual_diffInteraction(cellchat, weight.scale = T, measure = "weight")
dev.off()

p1 <- netVisual_heatmap(cellchat, measure = "count")
p2 <- netVisual_heatmap(cellchat, measure = "weight")

pdf(file="/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/cellchat_netVisual_heatmap_2.pdf",width = 12,height = 6)
p1 + p2
dev.off()

pdf(file="/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/cellchat_netVisual_circle_2.pdf",width = 20,height = 12)
par(mfrow = c(1, 2))
weight.max <- getMaxWeight(object.list, attribute = c("idents", "count"))
for (i in seq(length(object.list))){
	netVisual_circle(object.list[[i]]@net$count,weight.scale = T, label.edge = F,edge.weight.max = weight.max[2], edge.width.max = 12,title.name = paste0("Number of interactions - ", names(object.list)[i]))
}
dev.off()

num.link <- sapply(object.list, function(x) {rowSums(x@net$count) + colSums(x@net$count)-diag(x@net$count)})
weight.MinMax <- c(min(num.link), max(num.link)) # SN the dot size in the different datasets
gg <- list()
for (i in 1:length(object.list)){
	gg[[i]] <- netAnalysis_signalingRole_scatter(object.list[[i]], title = names(object.list)[i], weight.MinMax = weight.MinMax)
}
#> Signaling role analysis on the aggregated cell-cell communication network from all signaling pathways
#> Signaling role analysis on the aggregated cell-cell communication network from all signaling pathways
pdf(file="/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/cellchat_netAnalysis_computeCentrality_2.pdf",width = 16,height = 8)
patchwork::wrap_plots(plots = gg)
dev.off()

gg1 <- rankNet(cellchat, mode = "comparison", stacked = T, do.stat = TRUE)
gg2 <- rankNet(cellchat, mode = "comparison", stacked = F, do.stat = TRUE)

pdf(file="/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/cellchat_rankNet_2.pdf",width = 16,height = 10)
gg1 + gg2
dev.off()

library(ComplexHeatmap)
i = 1
# combining all the identified signaling pathways from different datasets
pathway.union <- union(object.list[[i]]@netP$pathways, object.list[[i+1]]@netP$pathways)
ht1 = netAnalysis_signalingRole_heatmap(object.list[[i]], pattern = "outgoing", signaling = pathway.union, title = names(object.list)[i], width = 8, height = 20)
ht2 = netAnalysis_signalingRole_heatmap(object.list[[i+1]], pattern = "outgoing", signaling = pathway.union, title = names(object.list)[i+1], width = 8, height = 20)
pdf(file="/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/cellchat_netAnalysis_signalingRole_heatmap_outgoing.pdf",width = 16,height = 16)
draw(ht1 + ht2, ht_gap = unit(0.5, "cm"))
dev.off()

ht1 = netAnalysis_signalingRole_heatmap(object.list[[i]], pattern = "incoming", signaling = pathway.union, title = names(object.list)[i], width = 8, height = 20, color.heatmap = "GnBu")
ht2 = netAnalysis_signalingRole_heatmap(object.list[[i+1]], pattern = "incoming", signaling = pathway.union, title = names(object.list)[i+1], width = 8, height = 20, color.heatmap = "GnBu")
pdf(file="/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/cellchat_netAnalysis_signalingRole_heatmap_incoming.pdf",width = 16,height = 16)
draw(ht1 + ht2, ht_gap = unit(0.5, "cm"))
dev.off()

ht1 = netAnalysis_signalingRole_heatmap(object.list[[i]], pattern = "all", signaling = pathway.union, title = names(object.list)[i], width = 8, height = 20, color.heatmap = "OrRd")
ht2 = netAnalysis_signalingRole_heatmap(object.list[[i+1]], pattern = "all", signaling = pathway.union, title = names(object.list)[i+1], width = 8, height = 20, color.heatmap = "OrRd")
pdf(file="/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/cellchat_netAnalysis_signalingRole_heatmap_all.pdf",width = 16,height = 16)
draw(ht1 + ht2, ht_gap = unit(0.5, "cm"))
dev.off()

pdf(file="/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/cellchat_circle_LAMININ.pdf",width = 16,height = 8)
pathways.show <- c("LAMININ") #热图查看cellchat_netAnalysis_signalingRole_heatmap_all.pdf对应细胞类型确定通路
#pathways.show <- intersect(cellchat_normal@netP$pathways,cellchat_tumor@netP$pathways) #取交集
weight.max <- getMaxWeight(object.list, slot.name = c("netP"), attribute = pathways.show) # SN the edge weights across different datasets
#weight.max <- sapply(pathways.show, function(pw) {getMaxWeight(object.list,slot.name = "netP",attribute = pw)})
par(mfrow = c(1,2), xpd=TRUE)
for (i in 1:length(object.list)){
	netVisual_aggregate(object.list[[i]], signaling = pathways.show, layout = "circle", edge.weight.max = weight.max[1], edge.width.max = 10, signaling.name = paste(pathways.show, names(object.list)[i]))
}
dev.off()

pdf(file="/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/cellchat_Heatmap_LAMININ.pdf",width = 12,height = 8)
pathways.show <- c("LAMININ")
par(mfrow = c(1,2), xpd=TRUE)
ht <- list()
for (i in 1:length(object.list)){
	ht[[i]] <- netVisual_heatmap(object.list[[i]], signaling = pathways.show, color.heatmap = "Reds",title.name = paste(pathways.show, "signaling ",names(object.list)[i]))
}
ComplexHeatmap::draw(ht[[1]] + ht[[2]], ht_gap = unit(0.5, "cm"))
dev.off()

pathways.common <- intersect(cellchat_normal@netP$pathways,cellchat_tumor@netP$pathways)
object.list <- list(Normal = cellchat_normal,Tumor  = cellchat_tumor)
for (pathway in pathways.common){
  ht <- list()
  for (nm in names(object.list)) {
    ht[[nm]] <- netVisual_heatmap(object.list[[nm]],signaling = pathway,color.heatmap = "Reds",title.name = paste(pathway, "signaling", nm))
  }
  ComplexHeatmap::draw(ht[[1]] + ht[[2]],ht_gap = unit(0.5, "cm"))
}
dev.off()

cellchat@meta$datasets = factor(cellchat@meta$datasets, levels = c("normal", "tumor"))
pdf(file="/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/cellchat_plotGeneExpression_LAMININ.pdf",width = 10,height = 8)
plotGeneExpression(cellchat, signaling = "LAMININ", split.by = "datasets", colors.ggplot = T)
dev.off()

# define a positive dataset, i.e., the dataset with positive fold change against the other dataset
pos.dataset = "tumor"
# define a char name used for storing the results of differential expression analysis
features.name = pos.dataset
# perform differential expression analysis
cellchat <- identifyOverExpressedGenes(cellchat, group.dataset = "datasets", pos.dataset = pos.dataset, features.name = features.name, only.pos = FALSE, thresh.pc = 0.1, thresh.fc = 0.1, thresh.p = 1)
#> Use the joint cell labels from the merged CellChat object
# map the results of differential expression analysis onto the inferred cell-cell communications to easily manage/subset the ligand-receptor pairs of interest
net <- netMappingDEG(cellchat, features.name = features.name)
# extract the ligand-receptor pairs with upregulated ligands in LS
net.up <- subsetCommunication(cellchat, net = net, datasets = "tumor",ligand.logFC = 0.2, receptor.logFC = NULL)
# extract the ligand-receptor pairs with upregulated ligands and upregulated recetptors in NL, i.e.,downregulated in LS
net.down <- subsetCommunication(cellchat, net = net, datasets = "normal",ligand.logFC = -0.1, receptor.logFC = -0.1)
net_merge=rbind(net.up,net.down)
write.csv(net_merge,"/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/cellchat_ligand_receptor_pairs_comparion_dif.csv")

net_Inflammatory_squamous_epithelial_cells_source=net_merge[net_merge$source=="Inflammatory squamous epithelial cells",]
net_Inflammatory_squamous_epithelial_cells_target=net_merge[net_merge$target=="Inflammatory squamous epithelial cells",]
net_Inflammatory_squamous_epithelial_cells_merge=rbind(net_Inflammatory_squamous_epithelial_cells_source,net_Inflammatory_squamous_epithelial_cells_target)
net_Inflammatory_squamous_epithelial_cells_merge=unique(net_Inflammatory_squamous_epithelial_cells_merge)
levels(cellchat@idents$normal)
levels(cellchat@idents$tumor)
write.csv(net_Inflammatory_squamous_epithelial_cells_merge,"/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/cellchat_ligand_receptor_pairs_comparion_dif_Inflammatory_squamous_epithelial_cells.csv")

pairLR.use.up = net_Inflammatory_squamous_epithelial_cells_merge[, "interaction_name", drop = F]
gg1 <- netVisual_bubble(cellchat, pairLR.use = pairLR.use.up, sources.use = 3, targets.use = c(1:18), comparison = c(1, 2),  angle.x = 90, remove.isolate = T,title.name = paste0("Inflammatory_squamous_epithelial_cells in ", names(object.list)[1], " and ", names(object.list)[2]))
gg2 <- netVisual_bubble(cellchat, pairLR.use = pairLR.use.up, sources.use = c(1:18), targets.use = 3, comparison = c(1, 2),  angle.x = 90, remove.isolate = T,title.name = paste0("Inflammatory_squamous_epithelial_cells in ", names(object.list)[1], " and ", names(object.list)[2]))

pdf(file="/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/cellchat_pairLR_bubble_net_Inflammatory_squamous_epithelial_cells_merge_in_tumor_and_normal.pdf",width = 17,height = 16)
gg1 + gg2
dev.off()

net_Inflammatory_squamous_epithelial_cells_LAMININ = net_Inflammatory_squamous_epithelial_cells_merge[net_Inflammatory_squamous_epithelial_cells_merge$pathway_name=="LAMININ",]
net_Inflammatory_squamous_epithelial_cells_MK = net_Inflammatory_squamous_epithelial_cells_merge[net_Inflammatory_squamous_epithelial_cells_merge$pathway_name=="MK",]
net_Inflammatory_squamous_epithelial_cells_GAP = net_Inflammatory_squamous_epithelial_cells_merge[net_Inflammatory_squamous_epithelial_cells_merge$pathway_name=="GAP",]
net_Inflammatory_squamous_epithelial_cells_MIF = net_Inflammatory_squamous_epithelial_cells_merge[net_Inflammatory_squamous_epithelial_cells_merge$pathway_name=="MIF",]
net_Inflammatory_squamous_epithelial_cells_CLDN = net_Inflammatory_squamous_epithelial_cells_merge[net_Inflammatory_squamous_epithelial_cells_merge$pathway_name=="CLDN",]
net_Inflammatory_squamous_epithelial_cells_ADGRG = net_Inflammatory_squamous_epithelial_cells_merge[net_Inflammatory_squamous_epithelial_cells_merge$pathway_name=="ADGRG",]
net_Inflammatory_squamous_epithelial_cells_RA = net_Inflammatory_squamous_epithelial_cells_merge[net_Inflammatory_squamous_epithelial_cells_merge$pathway_name=="RA",]
net_Inflammatory_squamous_epithelial_cells_merge = rbind(net_Inflammatory_squamous_epithelial_cells_LAMININ,net_Inflammatory_squamous_epithelial_cells_MK,net_Inflammatory_squamous_epithelial_cells_GAP,net_Inflammatory_squamous_epithelial_cells_MIF,net_Inflammatory_squamous_epithelial_cells_CLDN,net_Inflammatory_squamous_epithelial_cells_ADGRG,net_Inflammatory_squamous_epithelial_cells_RA)
net_Inflammatory_squamous_epithelial_cells_merge = unique(net_Inflammatory_squamous_epithelial_cells_merge)

pairLR.use.up = net_Inflammatory_squamous_epithelial_cells_merge[, "interaction_name", drop = F]
gg1 <- netVisual_bubble(cellchat, pairLR.use = pairLR.use.up, sources.use = 3, targets.use = c(1:18), comparison = c(1, 2),  angle.x = 90, remove.isolate = T,title.name = paste0("Epithelial_cells in ", names(object.list)[1], " and ", names(object.list)[2]))
pdf(file="/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/cellchat_pairLR_bubble_net_Inflammatory_squamous_epithelial_cells_merge_in_tumor_and_normal_select.pdf",width = 17,height = 16)
gg1
dev.off()

net_LAMININ = net_merge[net_merge$pathway_name=="LAMININ",]
pairLR.use.up = net_LAMININ[, "interaction_name", drop = F]
gg1 <- netVisual_bubble(cellchat, pairLR.use = pairLR.use.up, sources.use = 3, targets.use = c(1:18), comparison = c(1, 2),  angle.x = 90, remove.isolate = T,title.name = paste0("LAMININ signaling in ", names(object.list)[1], " and ", names(object.list)[2]))
gg2 <- netVisual_bubble(cellchat, pairLR.use = pairLR.use.up, sources.use = c(1:18), targets.use = 3, comparison = c(1, 2),  angle.x = 90, remove.isolate = T,title.name = paste0("LAMININ signaling in ", names(object.list)[1], " and ", names(object.list)[2]))
pdf(file = "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/cellchat_pairLR_bubble_LAMININ_signaling_in_tumor_and_normal.pdf",width = 17,height = 16)
gg1 + gg2
dev.off()

net_MK = net_merge[net_merge$pathway_name=="MK",]
pairLR.use.up = net_MK[, "interaction_name", drop = F]
gg1 <- netVisual_bubble(cellchat, pairLR.use = pairLR.use.up, sources.use = 3, targets.use = c(1:18), comparison = c(1, 2),  angle.x = 90, remove.isolate = T,title.name = paste0("MK signaling in ", names(object.list)[1], " and ", names(object.list)[2]))
gg2 <- netVisual_bubble(cellchat, pairLR.use = pairLR.use.up, sources.use = c(1:18), targets.use = 3, comparison = c(1, 2),  angle.x = 90, remove.isolate = T,title.name = paste0("MK signaling in ", names(object.list)[1], " and ", names(object.list)[2]))
pdf(file = "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/cellchat_pairLR_bubble_MK_signaling_in_tumor_and_normal.pdf",width = 15,height = 6)
gg1 + gg2
dev.off()

net_GAP = net_merge[net_merge$pathway_name=="GAP",]
pairLR.use.up = net_GAP[, "interaction_name", drop = F]
gg1 <- netVisual_bubble(cellchat, pairLR.use = pairLR.use.up, sources.use = 3, targets.use = c(1:18), comparison = c(1, 2),  angle.x = 90, remove.isolate = T,title.name = paste0("GAP signaling in ", names(object.list)[1], " and ", names(object.list)[2]))
gg2 <- netVisual_bubble(cellchat, pairLR.use = pairLR.use.up, sources.use = c(1:18), targets.use = 3, comparison = c(1, 2),  angle.x = 90, remove.isolate = T,title.name = paste0("GAP signaling in ", names(object.list)[1], " and ", names(object.list)[2]))
pdf(file = "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/cellchat_pairLR_bubble_GAP_signaling_in_tumor_and_normal.pdf",width = 15,height = 6)
gg1 + gg2
dev.off()

net_MIF = net_merge[net_merge$pathway_name=="MIF",]
pairLR.use.up = net_MIF[, "interaction_name", drop = F]
gg1 <- netVisual_bubble(cellchat, pairLR.use = pairLR.use.up, sources.use = 3, targets.use = c(1:18), comparison = c(1, 2),  angle.x = 90, remove.isolate = T,title.name = paste0("MIF signaling in ", names(object.list)[1], " and ", names(object.list)[2]))
gg2 <- netVisual_bubble(cellchat, pairLR.use = pairLR.use.up, sources.use = c(1:18), targets.use = 3, comparison = c(1, 2),  angle.x = 90, remove.isolate = T,title.name = paste0("MIF signaling in ", names(object.list)[1], " and ", names(object.list)[2]))
pdf(file = "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/cellchat_pairLR_bubble_MIF_signaling_in_tumor_and_normal.pdf",width = 15,height = 6)
gg1 + gg2
dev.off()

net_CLDN = net_merge[net_merge$pathway_name=="CLDN",]
pairLR.use.up = net_CLDN[, "interaction_name", drop = F]
gg1 <- netVisual_bubble(cellchat, pairLR.use = pairLR.use.up, sources.use = 3, targets.use = c(1:18), comparison = c(1, 2),  angle.x = 90, remove.isolate = T,title.name = paste0("CLDN signaling in ", names(object.list)[1], " and ", names(object.list)[2]))
gg2 <- netVisual_bubble(cellchat, pairLR.use = pairLR.use.up, sources.use = c(1:18), targets.use = 3, comparison = c(1, 2),  angle.x = 90, remove.isolate = T,title.name = paste0("CLDN signaling in ", names(object.list)[1], " and ", names(object.list)[2]))
pdf(file = "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/cellchat_pairLR_bubble_CLDN_signaling_in_tumor_and_normal.pdf",width = 15,height = 6)
gg1 + gg2
dev.off()

net_ADGRG = net_merge[net_merge$pathway_name=="ADGRG",]
pairLR.use.up = net_ADGRG[, "interaction_name", drop = F]
gg1 <- netVisual_bubble(cellchat, pairLR.use = pairLR.use.up, sources.use = 3, targets.use = c(1:18), comparison = c(1, 2),  angle.x = 90, remove.isolate = T,title.name = paste0("ADGRG signaling in ", names(object.list)[1], " and ", names(object.list)[2]))
gg2 <- netVisual_bubble(cellchat, pairLR.use = pairLR.use.up, sources.use = c(1:18), targets.use = 3, comparison = c(1, 2),  angle.x = 90, remove.isolate = T,title.name = paste0("ADGRG signaling in ", names(object.list)[1], " and ", names(object.list)[2]))
pdf(file = "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/cellchat_pairLR_bubble_ADGRG_signaling_in_tumor_and_normal.pdf",width = 15,height = 6)
gg1 + gg2
dev.off()

net_RA = net_merge[net_merge$pathway_name=="RA",]
pairLR.use.up = net_RA[, "interaction_name", drop = F]
gg1 <- netVisual_bubble(cellchat, pairLR.use = pairLR.use.up, sources.use = 3, targets.use = c(1:18), comparison = c(1, 2),  angle.x = 90, remove.isolate = T,title.name = paste0("RA signaling in ", names(object.list)[1], " and ", names(object.list)[2]))
gg2 <- netVisual_bubble(cellchat, pairLR.use = pairLR.use.up, sources.use = c(1:18), targets.use = 3, comparison = c(1, 2),  angle.x = 90, remove.isolate = T,title.name = paste0("RA signaling in ", names(object.list)[1], " and ", names(object.list)[2]))
pdf(file = "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellCellCommunication/Epithelial_cells/cellchat_pairLR_bubble_RA_signaling_in_tumor_and_normal.pdf",width = 15,height = 6)
gg1 + gg2
dev.off()