mkdir Epithelial_cells
/data/share03/Software/R-4.4.1/bin/Rscript get_SampleGroup_data.R

/data/share03/Software/R-4.4.1/bin/Rscript diff_group_CellChat.R
