#!/usr/bin/Rscript
# _*_ coding: utf-8 _*_

library(ggplot2)
library(optparse)
library(dplyr)
library(ggrepel)

#step1
option_list <- list(
        	make_option(c("-i", "--input"), type = "character", default = FALSE, action = "store", help = "This is input file!"),
	make_option(c("-g", "--group"), type = "character", default = FALSE, action = "store", help = "This is group information!"),
	make_option(c("-f", "--foldchange"), type = "double", default = FALSE, action = "store", help = "This is foldchange Cutoff"),
	make_option(c("-p", "--pvalue"), type = "double", default = FALSE, action = "store", help = "This is pvalue Cutoff"),
	make_option(c("-q", "--padj"), type = "double", default = FALSE, action = "store", help = "This is padj Cutoff"),
        	make_option(c("-o", "--output"), type = "character", default = FALSE, action = "store", help = "This is output file!"))

#step2
opt_parse = OptionParser(usage = "usage: %prog [options]", option_list = option_list, add_help_option = TRUE, prog = NULL, description = "")

#step3
opt = parse_args(opt_parse)

#step4
inputfile = opt$input
group = opt$group
outputfile = opt$output
cut_off_logFC = opt$foldchange
cut_off_pvalue = opt$pvalue
cut_off_padj =  opt$padj

dataset <- read.table(file = inputfile, header = TRUE, sep = "\t", check.names = FALSE)

dataset <- na.omit(dataset)

dataset$change = ifelse(dataset$pvalue < cut_off_pvalue & abs(dataset$logFC) > cut_off_logFC, 
                 ifelse(dataset$logFC > cut_off_logFC, 'Up', 'Down'), 'Stable')
#head(dataset)
deg <- dataset %>% filter(pvalue < cut_off_pvalue & abs(logFC) > cut_off_logFC)
top_up <- deg %>% filter(logFC > 0) %>% arrange(pvalue) %>% slice_head(n = 5)
top_down <- deg %>% filter(logFC < 0) %>% arrange(pvalue) %>% slice_head(n = 5)

top_genes <- bind_rows(top_up, top_down)
mytheme <- theme(plot.title = element_text(size = 20, hjust = 0.5),
	panel.border = element_rect(color = "black", linewidth = 1, fill = NA),
	axis.text.x = element_text(size = 20),
	axis.text.y = element_text(size = 20),
	axis.title.x = element_text(size = 20),
	axis.title.y = element_text(size = 20),
	legend.title = element_text(size = 20),
	legend.text = element_text(size = 20),
	legend.position = "right",
	axis.line = element_blank(),
	axis.ticks = element_line(linewidth = 1, colour = "gray30"),
	axis.ticks.length = unit(1.5, units = "mm"))

p1 <- ggplot(
	dataset, aes(x = logFC, y = -log10(pvalue), colour = change)) +
	geom_point(alpha = 0.8, size = 3) +
	scale_color_manual(values = c("#546de5", "#d2dae2", "#ff4757")) +
	geom_vline(xintercept = c(-cut_off_logFC, cut_off_logFC), lty = 4, col = "black", lwd = 1) +
	geom_hline(yintercept = -log10(cut_off_pvalue), lty = 4, col = "black", lwd = 1) +
	labs(title = paste(group, " volcano plot"), x = "log2(fold change)", y = "-log10(pvalue)") +
	theme_bw() +
	mytheme +
	geom_text_repel(data = top_genes, aes(label = Gene), size = 6, box.padding = 0.5, point.padding = 0.4, max.overlaps = Inf, show.legend = FALSE)

#print to png
png(paste0(outputfile, ".png"), width = 10, height = 12, units = "in", res = 300)
p1
dev.off()

#print to pdf
pdf(paste0(outputfile, ".pdf"), width = 10, height = 12)
p1
dev.off()