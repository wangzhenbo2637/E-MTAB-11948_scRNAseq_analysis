#!/usr/bin/Rscript
# _*_ coding: utf-8 _*_

library(optparse)

#strp1
option_list <- list(
        make_option(c("-i", "--input"), type = "character", default = FALSE, action = "store", help = "This is input file!"),
        make_option(c("-o", "--output"), type = "character", default = FALSE, action = "store", help = "This is output file!"))

#step2
opt_parse = OptionParser(usage = "usage: %prog [options]", option_list = option_list, add_help_option = TRUE, prog = NULL, description = "")

#step3
opt = parse_args(opt_parse)

inputfile = opt$input
outfile = opt$output

data <- read.table(inputfile, header = TRUE, sep = "\t", check.names = FALSE, stringsAsFactors = FALSE)

expr_mat <- as.matrix(data[, -1])
rownames(expr_mat) <- data$Gene

sum_exp <- rowSums(expr_mat)
ord <- order(rownames(expr_mat), -sum_exp)
expr_mat <- expr_mat[ord, ]
expr_mat <- expr_mat[!duplicated(rownames(expr_mat)), ]

expr_log2 <- log2(expr_mat + 1)

out <- cbind(Gene = rownames(expr_log2), expr_log2)
write.table(out, file = outfile, sep = "\t", quote = FALSE, row.names = FALSE)