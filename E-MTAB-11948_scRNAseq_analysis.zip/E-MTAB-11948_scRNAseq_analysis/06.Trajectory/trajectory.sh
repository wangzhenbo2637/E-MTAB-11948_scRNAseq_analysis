/data/share03/Software/R-4.4.1/bin/Rscript /data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/Trajectory/Epithelial_cells/monocle3_Trajectory.R
