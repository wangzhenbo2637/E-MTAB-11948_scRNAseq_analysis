library(optparse)

#step1
option_list <- list(
        make_option(c("-i", "--input"), type = "character", default = FALSE, action = "store", help = "This is input file 1"),
        make_option(c("-f", "--file"), type = "character", default = FALSE, action = "store", help = "This is input file 2"),
        make_option(c("-o", "--outfile"), type = "character", default = FALSE, action = "store", help = "This is outfile"))

#step2
opt_parse = OptionParser(usage = "usage: %prog [options]", option_list = option_list, add_help_option = TRUE, prog = NULL, description = "")

#step3
opt = parse_args(opt_parse)

#step4
file1 = opt$input
file2 = opt$file
outfile = opt$outfile

gene1 <- read.table(file1, header = TRUE, stringsAsFactors = FALSE)$Gene
gene2 <- read.table(file2, header = TRUE, stringsAsFactors = FALSE)$Gene
common_genes <- intersect(gene1, gene2)
write.table(data.frame(Gene = common_genes), file = outfile, quote = FALSE, row.names = FALSE)