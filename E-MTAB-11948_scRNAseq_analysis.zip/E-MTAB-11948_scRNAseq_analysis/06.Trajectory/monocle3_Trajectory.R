library("Seurat")
library("monocle3")
library(dplyr)
library(ggplot2)

singlecell.data <- readRDS("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/SubCluster/CellTypeIdent/Epithelial_cells/after_RenameIdents.rds")

expression_matrix <- GetAssayData(singlecell.data, assay = "RNA", slot = "counts")
cell_metadata <- singlecell.data@meta.data
gene_annotation <- data.frame(gene_short_name = row.names(expression_matrix), row.names = row.names(expression_matrix))

cds <- new_cell_data_set(expression_matrix, cell_metadata = cell_metadata, gene_metadata = gene_annotation)
head(cds@colData,2)

cds <- preprocess_cds(cds, num_dim = 50)
cds <- align_cds(cds, alignment_group = "Sample")
#cds <- align_cds(cds, alignment_group = "batch", residual_model_formula_str = "~ bg.300.loading + bg.400.loading + bg.500.1.loading + bg.500.2.loading + bg.r17.loading + bg.b01.loading + bg.b02.loading")

cds <- reduce_dimension(cds, max_components = 2, preprocess_method = "PCA", reduction_method = "UMAP")
#pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/Trajectory/Epithelial_cells/1.umap.reduceDim.pdf")
p1 <- plot_cells(cds, label_groups_by_cluster = FALSE, color_cells_by = "celltype", group_label_size = 3.0)
#dev.off()
output_file1 <- "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/Trajectory/Epithelial_cells/1.umap.reduceDim"
ggsave(paste0(output_file1, ".png"), plot = p1, width = 180, height = 150, units = "mm", dpi = 300)
ggsave(paste0(output_file1, ".pdf"), plot = p1, width = 180, height = 150, units = "mm")
#ciliated_genes <- c("che-1", "hlh-17", "nhr-6", "dmd-6", "ceh-36", "ham-1")

#pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/Trajectory/Epithelial_cells/umap_genes.pdf")
#plot_cells(cds,
#           genes=ciliated_genes,
#           label_cell_groups=FALSE,
#           show_trajectory_graph=FALSE)
#dev.off()

cds <- cluster_cells(cds)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/Trajectory/Epithelial_cells/2.umap.partition.pdf")
plot_cells(cds, color_cells_by = "partition")
dev.off()

cds <- learn_graph(cds)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/Trajectory/Epithelial_cells/3.umap.learn_graph.pdf")
plot_cells(cds,
           color_cells_by = "celltype",
           label_groups_by_cluster=FALSE,
           label_leaves=FALSE,
           label_branch_points=FALSE)
dev.off()

#pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/Trajectory/Epithelial_cells/4.umap.for_root.pdf")
p2 <- plot_cells(cds,
           color_cells_by = "celltype",
           label_cell_groups = FALSE,
           label_leaves = TRUE,
           label_branch_points = TRUE,
           graph_label_size = 2.0)
#dev.off()
output_file1 <- "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/Trajectory/Epithelial_cells/4.umap.for_root"
ggsave(paste0(output_file1, ".png"), plot = p2, width = 180, height = 150, units = "mm", dpi = 300)
ggsave(paste0(output_file1, ".pdf"), plot = p2, width = 180, height = 150, units = "mm")
#cds <- order_cells(cds)
#cds <- order_cells(cds, root_cells = root.cell)

# a helper function to identify the root principal points:
get_earliest_principal_node <- function(cds, sample="Basal epithelial cells"){
  cell_ids <- which(colData(cds)[, "celltype"] == sample)
  closest_vertex <- cds@principal_graph_aux[["UMAP"]]$pr_graph_cell_proj_closest_vertex
  closest_vertex <- as.matrix(closest_vertex[colnames(cds), ])
  root_pr_nodes <- igraph::V(principal_graph(cds)[["UMAP"]])$name[as.numeric(names(which.max(table(closest_vertex[cell_ids,]))))]
  root_pr_nodes
}
cds <- order_cells(cds, root_pr_nodes=get_earliest_principal_node(cds))

#pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/Trajectory/Epithelial_cells/5.umap.pseudotime.pdf")
p3 <- plot_cells(cds,
           color_cells_by = "pseudotime",
           label_cell_groups = FALSE,
           label_leaves = FALSE,
           label_branch_points = FALSE,
           graph_label_size = 1.5)
#dev.off()
output_file2 <- "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/Trajectory/Epithelial_cells/5.umap.pseudotime"
ggsave(paste0(output_file2, ".png"), plot = p3, width = 180, height = 150, units = "mm", dpi = 300)
ggsave(paste0(output_file2, ".pdf"), plot = p3, width = 180, height = 150, units = "mm")

deg <- graph_test(cds, neighbor_graph="principal_graph", cores=4)

trajectory_genes <- deg %>%
  dplyr::filter(q_value < 0.05, morans_I > 0.1) %>%
  dplyr::arrange(desc(morans_I))
write.table(trajectory_genes, file = "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/Trajectory/Epithelial_cells/DiffExpGene.xls", sep = "\t", row.names = T, quote = FALSE, col.names = NA)

#gene_module <- find_gene_modules(cds[row.names(trajectory_genes),],resolution = 1e-2)
#plot_cells(cds,genes=gene_module,show_trajectory_graph=FALSE)
