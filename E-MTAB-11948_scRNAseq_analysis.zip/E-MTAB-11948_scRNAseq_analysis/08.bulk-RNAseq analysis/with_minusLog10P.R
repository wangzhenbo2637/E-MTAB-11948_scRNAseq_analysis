#!/usr/bin/Rscript
# _*_ coding: utf-8 _*_
library(optparse)

#step1
option_list <- list(
        make_option(c("-i", "--input"), type = "character", default = FALSE, action = "store", help = "This is input file!"),
        make_option(c("-o", "--output"), type = "character", default = FALSE, action = "store", help = "This is output file!"))

#step2
opt_parse = OptionParser(usage = "usage: %prog [options]", option_list = option_list, add_help_option = TRUE, prog = NULL, description = "")

#step3
opt = parse_args(opt_parse)

#step4
inputfile = opt$input
outputfile = opt$output

df <- read.table(file = inputfile, header = TRUE, sep = "\t")
df$minusLog10P <- -log10(df$pvalue)

write.table(df, file = outputfile, sep = "\t", quote = FALSE, row.names = FALSE)