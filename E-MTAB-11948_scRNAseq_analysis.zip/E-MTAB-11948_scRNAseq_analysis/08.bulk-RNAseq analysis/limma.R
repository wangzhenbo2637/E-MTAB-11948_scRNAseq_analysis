#!/usr/bin/Rscript
# _*_ coding: utf-8 _*_
library(optparse)
library(limma)

#step1
option_list <- list(
        make_option(c("-i", "--input"), type = "character", default = FALSE, action = "store", help = "This is input file!"),
        make_option(c("-o", "--output"), type = "character", default = FALSE, action = "store", help = "This is output file!"))

#step2
opt_parse = OptionParser(usage = "usage: %prog [options]", option_list = option_list, add_help_option = TRUE, prog = NULL, description = "")

#step3
opt = parse_args(opt_parse)

#step4
inputfile = opt$input
outputfile = opt$output

expr <- read.table(file=inputfile, header=TRUE, row.names=1, sep="\t", check.names=FALSE)

group <- factor(c(rep("Normal", 10), rep("Tumor", 10)))
#batch <- c(rep("batch1", 24), rep("batch2", 3), rep("batch3", 17), rep("batch1", 49), rep("batch2", 3), rep("batch3", 15))

#design <- model.matrix(~0 + group + batch)
design <- model.matrix(~0 + group)
colnames(design) <- gsub("group", "", colnames(design))
design

fit <- lmFit(expr, design)

contrast <- makeContrasts(Tumor-Normal, levels=design)

fit2 <- contrasts.fit(fit, contrast)
fit2 <- eBayes(fit2)

deg <- topTable(fit2, adjust="BH", number=Inf)
head(deg)

write.table(deg, file=outputfile, sep="\t", quote=FALSE, row.names=TRUE)