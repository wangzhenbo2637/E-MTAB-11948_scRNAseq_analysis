#!/usr/bin/Rscript
# _*_ coding: utf-8 _*_
library(optparse)

#step1
option_list <- list(
        make_option(c("-i", "--input"), type = "character", default = FALSE, action = "store", help = "This is input file!"),
        make_option(c("-g", "--gene"), type = "character", default = FALSE, action = "store", help = "This is probe2gene file!"),
        make_option(c("-o", "--output"), type = "character", default = FALSE, action = "store", help = "This is output file!"))

#step2
opt_parse = OptionParser(usage = "usage: %prog [options]", option_list = option_list, add_help_option = TRUE, prog = NULL, description = "This Script is a probe2gene log2 gene matrix!")

#step3
opt = parse_args(opt_parse)

#step4
inputfile = opt$input
probe2gene = opt$gene
outputfile = opt$output

anno <- read.table(file = probe2gene,header = TRUE,sep = "\t",stringsAsFactors = FALSE)

expr <- read.table(file = inputfile,header = TRUE,sep = "\t",stringsAsFactors = FALSE,check.names = FALSE)

expr_anno <- merge(anno,expr,by.x = "ID",by.y = "ID_REF")

expr_anno <- expr_anno[expr_anno$GENE_SYMBOL != "" & !is.na(expr_anno$GENE_SYMBOL), ]

expr_gene <- expr_anno[, -(1:2)]

expr_gene <- aggregate(expr_gene,by = list(GENE_SYMBOL = expr_anno$GENE_SYMBOL),FUN = mean)
rownames(expr_gene) <- expr_gene$GENE_SYMBOL
expr_gene$GENE_SYMBOL <- NULL

expr_gene_log2 <- log2(expr_gene + 1)

write.table(expr_gene_log2,file = outputfile,sep = "\t",quote = FALSE)