#!/usr/bin/Rscript
# _*_ coding: utf-8 _*_

#install.packages("BiocManager")
#BiocManager::install("clusterProfiler")
#BiocManager::install("org.Mm.eg.db")
library(optparse)
library(ggplot2)
library(stringr)
library(enrichplot)
library(clusterProfiler)

#step1
option_list <- list(
        	make_option(c("-i", "--input"), type = "character", default = FALSE, action = "store", help = "This is input file!"),
	make_option(c("-d", "--OrgDb"), type = "character", default = FALSE, action = "store", help = "This is OrgDb species!"),
	make_option(c("-s", "--organism"), type = "character", default = FALSE, action = "store", help = "This is organism species!"),
	make_option(c("-g", "--genome"), type = "character", default = FALSE, action = "store", help = "This is Reference genome!"),
	make_option(c("-p", "--pvalue"), type = "double", default = FALSE, action = "store", help = "This is pvalue Cutoff"),
	make_option(c("-q", "--qvalue"), type = "double", default = FALSE, action = "store", help = "This is qvalue Cutoff"),
        	make_option(c("-o", "--outpath"), type = "character", default = FALSE, action = "store", help = "This is outpath!"))

#step2
opt_parse = OptionParser(usage = "usage: %prog [options]", option_list = option_list, add_help_option = TRUE, prog = NULL, description = "")

#step3
opt = parse_args(opt_parse)

#step4
inputfile = opt$input
outpath = opt$outpath
OrgDb_species = opt$OrgDb
organism_species = opt$organism
Reference_genome = opt$genome
pvalue = opt$pvalue
qvalue = opt$qvalue
library(OrgDb_species,character.only = TRUE)

data <- read.table(file = inputfile, header = TRUE, sep = "\t", check.names = FALSE)

GO_database <- OrgDb_species #http://bioconductor.org/packages/release/BiocViews.html#___OrgDb
KEGG_database <- organism_species #http://www.genome.jp/kegg/catalog/org_list.html

database_name = strsplit(Reference_genome, "_")
if (grepl(database_name[[1]], "Ensembl")){
	gene <<- bitr(data$Genename, fromType = 'ENSEMBL', toType = c('SYMBOL','ENTREZID'), OrgDb = GO_database)
	keytype <<- "ENSEMBL"
}else{
	gene <<- bitr(data$Genename, fromType = 'SYMBOL', toType = 'ENTREZID', OrgDb = GO_database)
	keytype <<- "SYMBOL"
}

GO <- enrichGO(gene = gene$ENTREZID,
	OrgDb = GO_database,
	keyType = "ENTREZID",
	ont = "ALL",
	pAdjustMethod = "BH",
	pvalueCutoff = pvalue,
	qvalueCutoff = qvalue,
	minGSSize = 1,
	maxGSSize = 1000,
	readable = T)

go <- as.data.frame(GO)
go$Hyperlink <- paste0("https://amigo.geneontology.org/amigo/term/", go$ID)
#table(go[,1])

go_MF <- go[go$ONTOLOGY == "MF",][1:10,]
go_CC <- go[go$ONTOLOGY == "CC",][1:10,]
go_BP <- go[go$ONTOLOGY == "BP",][1:10,]
go_enrich_df <- data.frame(ID = c(go_BP$ID, go_CC$ID, go_MF$ID),
	Description = c(go_BP$Description, go_CC$Description, go_MF$Description),
	GeneNumber = c(go_BP$Count, go_CC$Count, go_MF$Count),
	type = factor(c(rep("biological process", 10), rep("cellular component", 10), rep("molecular function", 10)),
	levels = c("molecular function", "cellular component", "biological process")))

labels = factor(go_enrich_df$Description, levels = c(go_enrich_df$Description))
#colors for bar green, blue, orange
CPCOLS <- c("#8DA1CB", "#FD8D62", "#66C3A5")

mytheme1 <- theme(plot.title = element_text(size = 13, hjust = 0.5),
        panel.border = element_rect(color = "black", linewidth = 1, fill = NA),
        axis.text.x = element_text(size = 10),
        axis.text.y = element_text(size = 10),
        axis.title.x = element_text(size = 12),
        axis.title.y = element_text(size = 12),
        legend.title = element_text(size = 10),
        legend.text = element_text(size = 9),
        legend.key.size = unit(0.4, units = "cm"),
        axis.line = element_blank(),
        axis.ticks = element_line(linewidth = 1, colour = "gray30"),
        axis.ticks.length = unit(1.5, units = "mm"))

mytheme2 <- theme(axis.line = element_line(colour = "black"),
	axis.text = element_text(color = 'black'),
	panel.grid = element_line(color = 'grey'),
	panel.border = element_rect(fill = 'transparent',color = 'black'),
	panel.background = element_rect(fill = 'transparent', color = 'grey50'),
	plot.title = element_text(hjust = 0.5, size = 20),
	axis.text.x = element_text(size = 20),
	axis.text.y = element_text(size = 20),
	axis.title = element_text(size = 20),
	legend.title = element_text(size = 20),
	legend.text = element_text(size = 20))

mytheme3 <- theme(axis.line = element_line(colour = "black"),
	axis.text = element_text(color = 'black'),
	panel.grid = element_blank(),
	panel.border = element_rect(fill = 'transparent',color = 'black'),
	panel.background = element_rect(fill = 'transparent', color = 'grey50'),
	plot.title = element_text(hjust = 0.5, size = 20),
	axis.text.x = element_text(size = 20),
	axis.text.y = element_text(size = 20),
	axis.title = element_text(size = 20),
	legend.title = element_text(size = 20),
	legend.text = element_text(size = 20))

GO_term <- ggplot(data = go_enrich_df, aes(x = labels, y = GeneNumber, fill = type)) +
	geom_bar(stat = "identity", width = 0.8) + 
	scale_fill_manual(values = CPCOLS) +
	labs(title = "The Most Enriched GO Terms", x = "GO term") +
	theme_test() + mytheme1 +
	coord_flip()

output_file1 <- file.path(outpath, "GO_term.txt")
write.table(go, output_file1, sep = '\t', quote = FALSE, row.names = FALSE)

GO_BP <- enrichGO(gene$ENTREZID,
	OrgDb = GO_database,
	keyType = "ENTREZID",
	ont = "BP",
	pAdjustMethod = "BH",
	pvalueCutoff = pvalue,
	qvalueCutoff = qvalue,
	minGSSize = 1,
	maxGSSize = 1000,
	readable = T)

GO_CC <- enrichGO(gene$ENTREZID,
	OrgDb = GO_database,
	keyType = "ENTREZID",
	ont = "CC",
	pAdjustMethod = "BH",
	pvalueCutoff = pvalue,
	qvalueCutoff = qvalue,
	minGSSize = 1,
	maxGSSize = 1000,
	readable = T)

GO_MF <- enrichGO(gene$ENTREZID,
	OrgDb = GO_database,
	keyType = "ENTREZID",
	ont = "MF",
	pAdjustMethod = "BH",
	pvalueCutoff = pvalue,
	qvalueCutoff = qvalue,
	minGSSize = 1,
	maxGSSize = 1000,
	readable = T)

output_file2 <- file.path(outpath, "GO_term")
output_file3 <- file.path(outpath, "GO_BP_dotplot")
output_file4 <- file.path(outpath, "GO_CC_dotplot")
output_file5 <- file.path(outpath, "GO_MF_dotplot")
output_file6 <- file.path(outpath, "GO_BP_barplot")
output_file7 <- file.path(outpath, "GO_CC_barplot")
output_file8 <- file.path(outpath, "GO_MF_barplot")
output_file9 <- file.path(outpath, "GO_BP_cnetplot")
output_file10 <- file.path(outpath, "GO_CC_cnetplot")
output_file11 <- file.path(outpath, "GO_MF_cnetplot")
#output_file12 <- file.path(outpath, "GO_BP_emapplot")
#output_file13 <- file.path(outpath, "GO_CC_emapplot")
#output_file14 <- file.path(outpath, "GO_MF_emapplot")
output_file15 <- file.path(outpath, "GO_BPgraph")
output_file16 <- file.path(outpath, "GO_CCgraph")
output_file17 <- file.path(outpath, "GO_MFgraph")

GO_BP_plot <- GO_BP
GO_BP_plot@result$GeneRatio <- sapply(GO_BP_plot@result$GeneRatio, function(x){
        parts <- strsplit(x, "/")[[1]]
        as.numeric(parts[1]) / as.numeric(parts[2])
})
GO_CC_plot <- GO_CC
GO_CC_plot@result$GeneRatio <- sapply(GO_CC_plot@result$GeneRatio, function(x){
        parts <- strsplit(x, "/")[[1]]
        as.numeric(parts[1]) / as.numeric(parts[2])
})
GO_MF_plot <- GO_MF
GO_MF_plot@result$GeneRatio <- sapply(GO_MF_plot@result$GeneRatio, function(x){
        parts <- strsplit(x, "/")[[1]]
        as.numeric(parts[1]) / as.numeric(parts[2])
})

GO_BP_dotplot <- ggplot(GO_BP_plot[1:20,], aes(x = GeneRatio, y = reorder(Description, p.adjust), size = Count, color = p.adjust)) +
        geom_point() +
        scale_size_continuous(range = c(8, 15)) +
        labs(title = "Top 20 Enriched GO BP Term", x = "GeneRatio", y = "Description") +
        scale_color_gradient(low = "red", high = "green") +
        scale_y_discrete(labels = function(x) str_wrap(x, width = 60)) +
        mytheme2
output_file18 <- file.path(outpath, "GO_BP_dotplot.txt")
write.table(GO_BP[1:20,], output_file18, sep = '\t', quote = FALSE, row.names = FALSE)

GO_CC_dotplot <- ggplot(GO_CC_plot[1:20,], aes(x = GeneRatio, y = reorder(Description, p.adjust), size = Count, color = p.adjust)) +
        geom_point() +
        scale_size_continuous(range = c(8, 15)) +
        labs(title = "Top 20 Enriched GO CC Term", x = "GeneRatio", y = "Description") +
        scale_color_gradient(low = "red", high = "green") +
        scale_y_discrete(labels = function(x) str_wrap(x, width = 60)) +
        mytheme2
output_file19 <- file.path(outpath, "GO_CC_dotplot.txt")
write.table(GO_CC[1:20,], output_file19, sep = '\t', quote = FALSE, row.names = FALSE)

GO_MF_dotplot <- ggplot(GO_MF_plot[1:20,], aes(x = GeneRatio, y = reorder(Description, p.adjust), size = Count, color = p.adjust)) +
        geom_point() +
        scale_size_continuous(range = c(8, 15)) +
        labs(title = "Top 20 Enriched GO MF Term", x = "GeneRatio", y = "Description") +
        scale_color_gradient(low = "red", high = "green") +
        scale_y_discrete(labels = function(x) str_wrap(x, width = 60)) +
        mytheme2
output_file20 <- file.path(outpath, "GO_MF_dotplot.txt")
write.table(GO_MF[1:20,], output_file20, sep = '\t', quote = FALSE, row.names = FALSE)

GO_BP_barplot <- ggplot(GO_BP_plot[1:20,], aes(x = Count, y = reorder(Description, p.adjust), fill = p.adjust)) +
        geom_bar(stat = "identity") +
        geom_text(aes(label = Count), hjust = -0.2, size = 8) +
        labs(title = "Top 20 Enriched GO BP Term", x = "Count", y = "Description") +
        scale_fill_gradient(low = "#0895AF", high = "#9BD8CC") +
        scale_y_discrete(labels = function(x) str_wrap(x, width = 60)) +
        mytheme3
output_file21 <- file.path(outpath, "GO_BP_barplot.txt")
write.table(GO_BP[1:20,], output_file21, sep = '\t', quote = FALSE, row.names = FALSE)

GO_CC_barplot <- ggplot(GO_CC_plot[1:20,], aes(x = Count, y = reorder(Description, p.adjust), fill = p.adjust)) +
        geom_bar(stat = "identity") +
        geom_text(aes(label = Count), hjust = -0.2, size = 8) +
        labs(title = "Top 20 Enriched GO CC Term", x = "Count", y = "Description") +
        scale_fill_gradient(low = "#0895AF", high = "#9BD8CC") +
        scale_y_discrete(labels = function(x) str_wrap(x, width = 60)) +
        mytheme3
output_file22 <- file.path(outpath, "GO_CC_barplot.txt")
write.table(GO_CC[1:20,], output_file22, sep = '\t', quote = FALSE, row.names = FALSE)

GO_MF_barplot <- ggplot(GO_MF_plot[1:20,], aes(x = Count, y = reorder(Description, p.adjust), fill = p.adjust)) +
        geom_bar(stat = "identity") +
        geom_text(aes(label = Count), hjust = -0.2, size = 8) +
        labs(title = "Top 20 Enriched GO MF Term", x = "Count", y = "Description") +
        scale_fill_gradient(low = "#0895AF", high = "#9BD8CC") +
        scale_y_discrete(labels = function(x) str_wrap(x, width = 60)) +
        mytheme3
output_file23 <- file.path(outpath, "GO_MF_barplot.txt")
write.table(GO_MF[1:20,], output_file23, sep = '\t', quote = FALSE, row.names = FALSE)

GO_BP_cnetplot <- enrichplot::cnetplot(GO_BP, circular = FALSE, colorEdge = TRUE)
output_file24 <- file.path(outpath, "GO_BP_cnetplot.txt")
write.table(GO_BP, output_file24, sep = '\t', quote = FALSE, row.names = FALSE)

GO_CC_cnetplot <- enrichplot::cnetplot(GO_CC, circular = FALSE, colorEdge = TRUE)
output_file25 <- file.path(outpath, "GO_CC_cnetplot.txt")
write.table(GO_CC, output_file25, sep = '\t', quote = FALSE, row.names = FALSE)

GO_MF_cnetplot <- enrichplot::cnetplot(GO_MF, circular = FALSE, colorEdge = TRUE)
output_file26 <- file.path(outpath, "GO_MF_cnetplot.txt")
write.table(GO_MF, output_file26, sep = '\t', quote = FALSE, row.names = FALSE)

#GO2_BP <- pairwise_termsim(GO_BP)
#GO_BP_emapplot <- enrichplot::emapplot(GO2_BP, showCategory = 50, color = "p.adjust", layout = "kk")
#output_file27 <- file.path(outpath, "GO_BP_emapplot.txt")
#write.table(GO2_BP[1:50,], output_file27, sep = '\t', quote = FALSE, row.names = FALSE)

#GO2_CC <- pairwise_termsim(GO_CC)
#GO_CC_emapplot <- enrichplot::emapplot(GO2_CC, showCategory = 50, color = "p.adjust", layout = "kk")
#output_file28 <- file.path(outpath, "GO_CC_emapplot.txt")
#write.table(GO2_CC[1:50,], output_file28, sep = '\t', quote = FALSE, row.names = FALSE)

#GO2_MF <- pairwise_termsim(GO_MF)
#GO_MF_emapplot <- enrichplot::emapplot(GO2_MF, showCategory = 50, color = "p.adjust", layout = "kk")
#output_file29 <- file.path(outpath, "GO_MF_emapplot.txt")
#write.table(GO2_MF[1:50,], output_file29, sep = '\t', quote = FALSE, row.names = FALSE)

#print to png
ggsave(paste0(output_file2, ".png"), plot = GO_term, width = 180, height = 150, units = "mm", dpi = 300)
#png(paste0(output_file2, ".png"), width = 20, height = 12, units = "in", res = 300)
#png(paste0(output_file2, ".png"), width = 30, height = 12, units = "in", res = 300)
#GO_term
#dev.off()
png(paste0(output_file3, ".png"), width = 15, height = 18, units = "in", res = 300)
GO_BP_dotplot
dev.off()
png(paste0(output_file4, ".png"), width = 15, height = 18, units = "in", res = 300)
GO_CC_dotplot
dev.off()
png(paste0(output_file5, ".png"), width = 15, height = 18, units = "in", res = 300)
GO_MF_dotplot
dev.off()
png(paste0(output_file6, ".png"), width = 15, height = 18, units = "in", res = 300)
GO_BP_barplot
dev.off()
png(paste0(output_file7, ".png"), width = 15, height = 18, units = "in", res = 300)
GO_CC_barplot
dev.off()
png(paste0(output_file8, ".png"), width = 15, height = 18, units = "in", res = 300)
GO_MF_barplot
dev.off()
png(paste0(output_file9, ".png"), width = 15, height = 12, units = "in", res = 300)
GO_BP_cnetplot
dev.off()
png(paste0(output_file10, ".png"), width = 15, height = 12, units = "in", res = 300)
GO_CC_cnetplot
dev.off()
png(paste0(output_file11, ".png"), width = 15, height = 12, units = "in", res = 300)
GO_MF_cnetplot
dev.off()
#png(paste0(output_file12, ".png"), width = 15, height = 12, units = "in", res = 300)
#GO_BP_emapplot
#dev.off()
#png(paste0(output_file13, ".png"), width = 15, height = 12, units = "in", res = 300)
#GO_CC_emapplot
#dev.off()
#png(paste0(output_file14, ".png"), width = 15, height = 12, units = "in", res = 300)
#GO_MF_emapplot
#dev.off()
png(paste0(output_file15, ".png"), width = 12, height = 15, units = "in", res = 300)
plotGOgraph(GO_BP)
dev.off()
png(paste0(output_file16, ".png"), width = 12, height = 15, units = "in", res = 300)
plotGOgraph(GO_CC)
dev.off()
png(paste0(output_file17, ".png"), width = 12, height = 15, units = "in", res = 300)
plotGOgraph(GO_MF)
dev.off()

#print to pdf
ggsave(paste0(output_file2, ".pdf"), plot = GO_term, width = 180, height = 150, units = "mm")
#pdf(paste0(output_file2, ".pdf"), width = 20, height = 12)
#pdf(paste0(output_file2, ".pdf"), width = 30, height = 12)
#GO_term
#dev.off()
pdf(paste0(output_file3, ".pdf"), width = 15, height = 18)
GO_BP_dotplot
dev.off()
pdf(paste0(output_file4, ".pdf"), width = 15, height = 18)
GO_CC_dotplot
dev.off()
pdf(paste0(output_file5, ".pdf"), width = 15, height = 18)
GO_MF_dotplot
dev.off()
pdf(paste0(output_file6, ".pdf"), width = 15, height = 18)
GO_BP_barplot
dev.off()
pdf(paste0(output_file7, ".pdf"), width = 15, height = 18)
GO_CC_barplot
dev.off()
pdf(paste0(output_file8, ".pdf"), width = 15, height = 18)
GO_MF_barplot
dev.off()
pdf(paste0(output_file9, ".pdf"), width = 15, height = 12)
GO_BP_cnetplot
dev.off()
pdf(paste0(output_file10, ".pdf"), width = 15, height = 12)
GO_CC_cnetplot
dev.off()
pdf(paste0(output_file11, ".pdf"), width = 15, height = 12)
GO_MF_cnetplot
dev.off()
#pdf(paste0(output_file12, ".pdf"), width = 15, height = 12)
#GO_BP_emapplot
#dev.off()
#pdf(paste0(output_file13, ".pdf"), width = 15, height = 12)
#GO_CC_emapplot
#dev.off()
#pdf(paste0(output_file14, ".pdf"), width = 15, height = 12)
#GO_MF_emapplot
#dev.off()
pdf(paste0(output_file15, ".pdf"), width = 12, height = 15)
plotGOgraph(GO_BP)
dev.off()
pdf(paste0(output_file16, ".pdf"), width = 12, height = 15)
plotGOgraph(GO_CC)
dev.off()
pdf(paste0(output_file17, ".pdf"), width = 12, height = 15)
plotGOgraph(GO_MF)
dev.off()