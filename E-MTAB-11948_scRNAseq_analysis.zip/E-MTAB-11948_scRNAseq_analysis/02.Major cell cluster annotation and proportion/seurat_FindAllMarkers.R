#!/usr/bin/Rscript
# _*_ coding: utf-8 _*_

library(optparse)
library("Seurat")
library("dplyr")
library("ggplot2")

#strp1
option_list <- list(
        make_option(c("-i", "--input"), type = "character", default = FALSE, action = "store", help = "This is input file!"),
        make_option(c("-o", "--output"), type = "character", default = FALSE, action = "store", help = "This is output file!"))

#step2
opt_parse = OptionParser(usage = "usage: %prog [options]", option_list = option_list, add_help_option = TRUE, prog = NULL, description = "FindAllMarkers")

#step3 
opt = parse_args(opt_parse)

#step4 
inputfile = opt$input
outdir = opt$output

filtered.data <- readRDS(inputfile)
DefaultAssay(filtered.data) <- "RNA"

##FindAllMarkers
all.markers <- FindAllMarkers(filtered.data, only.pos = TRUE, min.pct = 0.25, logfc.threshold = 0.36, return.thresh = 0.01, test.use = "wilcox")
#write.table(all.markers, file = paste0(outdir,"DiffExpGene.xls"), sep = "\t", row.names = T, quote = FALSE, col.names=NA)

top2diff <- all.markers %>% group_by(cluster) %>% slice_max(n = 2, order_by = avg_log2FC)
topmarkers <- top2diff$gene
topmarkers
clusters <- unique(top2diff$cluster)

DefaultAssay(filtered.data) <- "RNA"
#Top 2 markers gene
P1 = DotPlot(object = filtered.data, features = unique(topmarkers))+
	scale_color_gradientn(colours = c('#330066','#336699','#66CC66','#FFCC33'))+
	theme(axis.text.x = element_text(angle = 45,vjust = 0.5,hjust = 0.5),
 	axis.title = element_text(size = 11, color = "black"), 
        	axis.text = element_text(size = 9, color = "black"), 
        	legend.text = element_text(size = 8, color = "black"), 
        	legend.title = element_text(size = 9, color = "black"))

ggsave(paste0(outdir,"TopMarkerGene_dotplot.pdf"), plot = P1, width = 440, height = 120, units = "mm")
ggsave(paste0(outdir,"TopMarkerGene_dotplot.png"), plot = P1, width = 440, height = 120, units = "mm")