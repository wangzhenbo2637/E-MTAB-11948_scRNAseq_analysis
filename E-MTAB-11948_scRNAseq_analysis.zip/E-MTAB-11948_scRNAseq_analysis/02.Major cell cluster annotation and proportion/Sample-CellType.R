library("ggplot2")
library("dplyr")

data <- read.table("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/Sample-CellType.CellNumber.4barplot", header = TRUE, check.names = FALSE, sep = "\t")

#data$CellType <- factor(data$CellType, levels = rev(unique(data$CellType)))
data$CellType <- factor(data$CellType, levels = unique(data$CellType))

pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/Sample-CellType.CellNumber.pdf")
ggplot(data, aes(x=Sample, y=CellNumber, fill=CellType)) + 
  geom_bar(stat = "identity", position = "stack", width = 0.75) + 
  labs(title="Number of Cells in Samples", x="Samples", y="Number of Cells") + 
  scale_fill_discrete(name = "CellType") + 
#  coord_flip(expand = T) + 
  theme(axis.line = element_line(colour = "black"),
        plot.title = element_text(hjust = 0.5),
        panel.grid.major = element_line(colour = "gray"),
        panel.grid.minor = element_blank(),
        panel.grid.major.x = element_blank(),
        panel.border = element_rect(fill='transparent',color='black'),
        panel.background = element_rect(fill='transparent', color='grey50'),
        axis.text.x = element_text(size=10,angle=45,hjust=1,vjust=1))
dev.off()

data <- read.table("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/Sample-CellType.CellFraction.4barplot", header = TRUE, check.names = FALSE, sep = "\t")

#data$CellType <- factor(data$CellType, levels = rev(unique(data$CellType)))
data$CellType <- factor(data$CellType, levels = unique(data$CellType))

pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/Sample-CellType.CellFraction.pdf")
ggplot(data, aes(x=Sample, y=CellFraction, fill=CellType)) + 
  geom_bar(stat = "identity", position = "stack", width = 0.75) + 
  labs(title="Fraction of Cells in Samples", x="Samples", y="Fraction of Cells") + 
  scale_fill_discrete(name = "CellType") + 
#  coord_flip(expand = T) + 
  theme(axis.line = element_line(colour = "black"),
        plot.title = element_text(hjust = 0.5),
        panel.grid.major = element_line(colour = "gray"),
        panel.grid.minor = element_blank(),
        panel.grid.major.x = element_blank(),
        panel.border = element_rect(fill='transparent',color='black'),
        panel.background = element_rect(fill='transparent', color='grey50'),
        axis.text.x = element_text(size=10,angle=45,hjust=1,vjust=1))
dev.off()