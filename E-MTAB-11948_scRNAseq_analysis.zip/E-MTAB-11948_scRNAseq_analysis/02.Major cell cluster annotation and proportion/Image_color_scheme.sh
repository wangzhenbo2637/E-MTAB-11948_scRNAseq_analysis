#UMAP_celltype UMAP_celltype_Group
/data/share03/Software/R-4.4.1/bin/Rscript ./scripts/UMAP_plot.R -i /data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/after_RenameIdents.rds -o /data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/

#Group-CellType.CellFraction
/data/share03/Software/R-4.4.1/bin/Rscript ./scripts/Group-CellType.R -i /data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/CellNumber.CellType-Group.xls -o /data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/

#MarkerGene_dotplot_celltype
/data/share03/Software/R-4.4.1/bin/Rscript ./scripts/seurat_FindAllMarkers.R -i /data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/after_RenameIdents.rds -o /data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/

#TopMarkerGene_dotplot
/data/share03/Software/R-4.4.1/bin/Rscript ./scripts/DotPlot.R -i /data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/after_RenameIdents.rds -g "CDKN2A,EPCAM,CD24,CDH1,PECAM1,CDH5,ENG,COL1A2,DCN,APOD,ACTA2,ACTG2,TAGLN,CD3E,CD3D,CD2,FCER1G,GLUL,TYROBP,CSF3R,CD79A,JCHAIN,IGKC" -o /data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/

#Fig_OR.all_cell.OR.dist
/data/share03/Software/R-4.4.1/bin/Rscript ./scripts/seurat_obj_meta.R -i /data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/after_RenameIdents.rds -o /data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/

#/data/share03/Software/R-4.4.1/bin/Rscript ./scripts/OR_valuea_analysis.R
