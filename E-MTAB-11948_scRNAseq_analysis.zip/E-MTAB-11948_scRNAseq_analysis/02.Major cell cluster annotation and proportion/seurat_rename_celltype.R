library("Seurat")
library("ggplot2")
library("dplyr")
library("cowplot")
library("patchwork")

singlecell.data <- readRDS("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/analysis-1/process/CellCluster_Seurat/after_cluster_cells.rds")

Idents(singlecell.data) <- "seurat_clusters"

DefaultAssay(singlecell.data) <- "integrated"
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/MarkerGene_heatmap_cluster.pdf", width=100, height=10)
DoHeatmap(object = singlecell.data, features = c("CDKN2A","EPCAM","CD24","CDH1","COL1A2","DCN","APOD","PECAM1","CDH5","ENG","ACTA2","ACTG2","TAGLN","CD3E","CD3D","CD2","CSF3R","CD68","CD163","LYZ","FCER1G","GLUL","TYROBP","CD79A","JCHAIN","IGKC")) + NoLegend()
dev.off()
DefaultAssay(singlecell.data) <- "RNA"

pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/MarkerGene_dotplot_cluster.pdf", width=20, height=10)
DotPlot(object = singlecell.data, features = c("CDKN2A","EPCAM","CD24","CDH1","COL1A2","DCN","APOD","PECAM1","CDH5","ENG","ACTA2","ACTG2","TAGLN","CD3E","CD3D","CD2","CSF3R","CD68","CD163","LYZ","FCER1G","GLUL","TYROBP","CD79A","JCHAIN","IGKC"))+theme(axis.text.x=element_text(angle=45,hjust=1))
dev.off()

pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/MarkerGene_violin_cluster.pdf", width=20, height=130)
VlnPlot(object = singlecell.data, features = c("CDKN2A","EPCAM","CD24","CDH1","COL1A2","DCN","APOD","PECAM1","CDH5","ENG","ACTA2","ACTG2","TAGLN","CD3E","CD3D","CD2","CSF3R","CD68","CD163","LYZ","FCER1G","GLUL","TYROBP","CD79A","JCHAIN","IGKC"), ncol = 2)
dev.off()

singlecell.data <- RenameIdents(singlecell.data, '0' = "Epithelial cells",'1' = "Fibroblasts cells",'2' = "Endothelial cells",'3' = "Smooth muscle cells",'4' = "Smooth muscle cells",'5' = "Epithelial cells",'6' = "Lymphocytes cells",'7' = "Epithelial cells",'8' = "Epithelial cells",'9' = "Epithelial cells",'10' = "Neutrophils cells",'11' = "Macrophage cells",'12' = "Macrophage cells",'13' = "Epithelial cells",'14' = "B cells",'15' = "Smooth muscle cells")
singlecell.data$celltype <- Idents(singlecell.data)

DefaultAssay(singlecell.data) <- "integrated"
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/MarkerGene_heatmap_celltype.pdf", width=100, height=10)
DoHeatmap(object = singlecell.data, features = c("CDKN2A","EPCAM","CD24","CDH1","COL1A2","DCN","APOD","PECAM1","CDH5","ENG","ACTA2","ACTG2","TAGLN","CD3E","CD3D","CD2","CSF3R","CD68","CD163","LYZ","FCER1G","GLUL","TYROBP","CD79A","JCHAIN","IGKC")) + NoLegend()
dev.off()
DefaultAssay(singlecell.data) <- "RNA"

pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/MarkerGene_dotplot_celltype.pdf", width=20, height=10)
DotPlot(object = singlecell.data, features = c("CDKN2A","EPCAM","CD24","CDH1","COL1A2","DCN","APOD","PECAM1","CDH5","ENG","ACTA2","ACTG2","TAGLN","CD3E","CD3D","CD2","CSF3R","CD68","CD163","LYZ","FCER1G","GLUL","TYROBP","CD79A","JCHAIN","IGKC"))+theme(axis.text.x=element_text(angle=45,hjust=1))
dev.off()

pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/MarkerGene_violin_celltype.pdf", width=20, height=130)
VlnPlot(object = singlecell.data, features = c("CDKN2A","EPCAM","CD24","CDH1","COL1A2","DCN","APOD","PECAM1","CDH5","ENG","ACTA2","ACTG2","TAGLN","CD3E","CD3D","CD2","CSF3R","CD68","CD163","LYZ","FCER1G","GLUL","TYROBP","CD79A","JCHAIN","IGKC"), ncol = 2)
dev.off()

pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/MarkerGene_umap_celltype.pdf", width=20, height=130)
FeaturePlot(object = singlecell.data, features = c("CDKN2A","EPCAM","CD24","CDH1","COL1A2","DCN","APOD","PECAM1","CDH5","ENG","ACTA2","ACTG2","TAGLN","CD3E","CD3D","CD2","CSF3R","CD68","CD163","LYZ","FCER1G","GLUL","TYROBP","CD79A","JCHAIN","IGKC"), label = TRUE, ncol = 2, raster = FALSE)
dev.off()

p1 <- DimPlot(object = singlecell.data, reduction = "umap", group.by = "Sample", raster = FALSE)
p2 <- DimPlot(object = singlecell.data, reduction = "umap", label = TRUE, raster = FALSE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/umap_celltype.pdf", width=22, height=10)
print(p1 + p2)
dev.off()

pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/umap_celltype_splitBySample.pdf", width = 30, height = 10)
DimPlot(object = singlecell.data, reduction = "umap", split.by = "Sample", raster = FALSE)
dev.off()

Normal_1.sub <- subset(singlecell.data, subset = Sample == "Normal_1")
Normal_1.p1 <- DimPlot(object = Normal_1.sub, reduction = "umap", group.by = "Sample")
Normal_1.p2 <- DimPlot(object = Normal_1.sub, reduction = "umap", label = TRUE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/umap_celltype.Normal_1.pdf", width=22, height=10)
print(Normal_1.p1 + Normal_1.p2)
dev.off()
rm(Normal_1.sub)

Normal_2.sub <- subset(singlecell.data, subset = Sample == "Normal_2")
Normal_2.p1 <- DimPlot(object = Normal_2.sub, reduction = "umap", group.by = "Sample")
Normal_2.p2 <- DimPlot(object = Normal_2.sub, reduction = "umap", label = TRUE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/umap_celltype.Normal_2.pdf", width=22, height=10)
print(Normal_2.p1 + Normal_2.p2)
dev.off()
rm(Normal_2.sub)

Normal_3.sub <- subset(singlecell.data, subset = Sample == "Normal_3")
Normal_3.p1 <- DimPlot(object = Normal_3.sub, reduction = "umap", group.by = "Sample")
Normal_3.p2 <- DimPlot(object = Normal_3.sub, reduction = "umap", label = TRUE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/umap_celltype.Normal_3.pdf", width=22, height=10)
print(Normal_3.p1 + Normal_3.p2)
dev.off()
rm(Normal_3.sub)

Tumor_1.sub <- subset(singlecell.data, subset = Sample == "Tumor_1")
Tumor_1.p1 <- DimPlot(object = Tumor_1.sub, reduction = "umap", group.by = "Sample")
Tumor_1.p2 <- DimPlot(object = Tumor_1.sub, reduction = "umap", label = TRUE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/umap_celltype.Tumor_1.pdf", width=22, height=10)
print(Tumor_1.p1 + Tumor_1.p2)
dev.off()
rm(Tumor_1.sub)

Tumor_2.sub <- subset(singlecell.data, subset = Sample == "Tumor_2")
Tumor_2.p1 <- DimPlot(object = Tumor_2.sub, reduction = "umap", group.by = "Sample")
Tumor_2.p2 <- DimPlot(object = Tumor_2.sub, reduction = "umap", label = TRUE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/umap_celltype.Tumor_2.pdf", width=22, height=10)
print(Tumor_2.p1 + Tumor_2.p2)
dev.off()
rm(Tumor_2.sub)

Tumor_3.sub <- subset(singlecell.data, subset = Sample == "Tumor_3")
Tumor_3.p1 <- DimPlot(object = Tumor_3.sub, reduction = "umap", group.by = "Sample")
Tumor_3.p2 <- DimPlot(object = Tumor_3.sub, reduction = "umap", label = TRUE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/umap_celltype.Tumor_3.pdf", width=22, height=10)
print(Tumor_3.p1 + Tumor_3.p2)
dev.off()
rm(Tumor_3.sub)

Idents(singlecell.data) <- "Sample"
singlecell.data <- RenameIdents(singlecell.data, 'Normal_3' = "Normal",'Tumor_3' = "Tumor",'Tumor_1' = "Tumor",'Tumor_2' = "Tumor",'Normal_2' = "Normal",'Normal_1' = "Normal")
singlecell.data$SampleGroup <- Idents(singlecell.data)
Idents(singlecell.data) <- "celltype"

p1 <- DimPlot(object = singlecell.data, reduction = "umap", group.by = "SampleGroup", raster = FALSE)
p2 <- DimPlot(object = singlecell.data, reduction = "umap", label = TRUE, raster = FALSE)
pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/umap_celltype_Group.pdf", width=22, height=10)
print(p1 + p2)
dev.off()

pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/umap_celltype_splitByGroup.pdf", width = 20, height = 10)
DimPlot(object = singlecell.data, reduction = "umap", split.by = "SampleGroup", raster = FALSE)
dev.off()

Tumor.cell <- subset(singlecell.data, subset = SampleGroup == "Tumor")

pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/Tumor.MarkerGene_umap.pdf", width=20, height=200)
FeaturePlot(object = Tumor.cell, features = c("CDKN2A","EPCAM","CD24","CDH1","COL1A2","DCN","APOD","PECAM1","CDH5","ENG","ACTA2","ACTG2","TAGLN","CD3E","CD3D","CD2","CSF3R","CD68","CD163","LYZ","FCER1G","GLUL","TYROBP","CD79A","JCHAIN","IGKC"), label = TRUE, ncol = 2, raster = FALSE)
dev.off()

Normal.cell <- subset(singlecell.data, subset = SampleGroup == "Normal")

pdf("/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/Normal.MarkerGene_umap.pdf", width=20, height=200)
FeaturePlot(object = Normal.cell, features = c("CDKN2A","EPCAM","CD24","CDH1","COL1A2","DCN","APOD","PECAM1","CDH5","ENG","ACTA2","ACTG2","TAGLN","CD3E","CD3D","CD2","CSF3R","CD68","CD163","LYZ","FCER1G","GLUL","TYROBP","CD79A","JCHAIN","IGKC"), label = TRUE, ncol = 2, raster = FALSE)
dev.off()

write.table(singlecell.data@meta.data, file = "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/cell2celltype.xls", quote=FALSE, sep = "\t", col.names=NA)

saveRDS(singlecell.data, file = "/data/share03/Products/RNA-Seq/10X_3CC_scRNA_seq/26HCF010036/advanced_analysis-1/CellTypeIdent/example/after_RenameIdents.rds")