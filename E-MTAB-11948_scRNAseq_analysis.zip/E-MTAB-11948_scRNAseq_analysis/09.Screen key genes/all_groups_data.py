#!/usr/bin/env python
# -*- coding=utf-8 -*-

import pandas as pd
import argparse
import os
from glob import glob

message = """
=====================================================================
Description: all groups data
Options:
	-f1|file1		input file1
    -f2|file2       input file2
	-f3|file3       input file3
	-f4|file4       input file4
    -o1|output1     output file1
	-o2|output2     output file2
	-o3|output3     output file3
	-o4|output4     output file4
    -h|help         display this help message

Author: wangzhenbo003
email: wangzhenbo003@frontiergene.com
Version: v1.0
Date: 2024.07.29
Modify: 2025.05.09

For example:
        python3 all_groups_data.py -f1 all_groups_heatmap.tmp.txt -o1 all_groups_heatmap.txt
=====================================================================
"""
parser = argparse.ArgumentParser(description = "all_groups_data file")
parser.add_argument("-f1", "--file1", help = "input violin data")
parser.add_argument("-f2", "--file2", help = "input heatmap data")
parser.add_argument("-f3", "--file3", help = "input venn data")
parser.add_argument("-f4", "--file4", help = "input geneexp data")
parser.add_argument("-o1", "--output1", help = "output violin data")
parser.add_argument("-o2", "--output2", help = "output heatmap")
parser.add_argument("-o3", "--output3", help = "output venn")
parser.add_argument("-o4", "--output4", help = "output geneexp")
args = vars(parser.parse_args())

VENN_FILE_SUFFIX = "_Venn_data.txt"

file1 = args['file1']
file2 = args['file2']
file3 = args['file3']
file4 = args['file4']
output1 = args['output1']
output2 = args['output2']
output3 = args['output3']
output4 = args['output4']

def get_violin_data(file1, output1):
	df1 = pd.read_csv(file1, sep = "\t")
	df2 = df1.drop_duplicates()
	df2.to_csv(output1, index = False, sep = "\t")

def get_heatmap_data(file2, output2):
	df1 = pd.read_csv(file2, sep = "\t")
	df2 = df1.T.drop_duplicates().T
	df2.to_csv(output2, index = False, sep = "\t")

def get_venn_group_name(file):
	file_name = os.path.basename(file)
	if not file_name.endswith(VENN_FILE_SUFFIX):
		raise ValueError("Venn data filename must end with " + VENN_FILE_SUFFIX)
	return file_name[:-len(VENN_FILE_SUFFIX)]

def get_venn_data(file3, output3):
	if os.path.isfile(file3):
		file_pattern = os.path.join(os.path.dirname(file3), "*" + VENN_FILE_SUFFIX)
	elif os.path.isdir(file3):
		file_pattern = os.path.join(file3, "*" + VENN_FILE_SUFFIX)
	else:
		file_pattern = file3 + "*" + VENN_FILE_SUFFIX
	file_list = glob(file_pattern)
	venn_list = []
	for file in file_list:
		group_name = get_venn_group_name(file)
		df1 = pd.read_csv(file, sep = "\t")
		gene_column = next((column for column in ("GeneName", "Genename") if column in df1.columns), None)
		if gene_column is None:
			raise ValueError(file + " must contain GeneName or Genename")
		df2 = df1.rename(columns = {gene_column:group_name})
		venn_list.append(df2)
	df3 = pd.concat(venn_list, axis = 1)
	df3.to_csv(output3, index = False, sep = "\t")

def get_GeneExp_data(file4, output4):
	df1 = pd.read_csv(file4, sep = "\t")
	# 去除重复列
	df2 = df1.T.drop_duplicates().T
	# 按后缀归类列
	df_fpkm = df2.filter(regex = "_FPKM$")
	df_tpm = df2.filter(regex = "_TPM$")
	df_readcounts = df2.filter(regex = "_ReadCounts$")
	df_gene = df2["GeneName"]
	df3 = pd.concat([df_gene, df_fpkm, df_tpm, df_readcounts], axis = 1)
	df3.to_csv(output4, index = False, sep = "\t")

def main():
	if file1 is not None:
		get_violin_data(file1, output1)
	elif file2 is not None:
		get_heatmap_data(file2, output2)
	elif file3 is not None:
		get_venn_data(file3, output3)
	elif file4 is not None:
		get_GeneExp_data(file4, output4)

if __name__ == '__main__':
	main()
