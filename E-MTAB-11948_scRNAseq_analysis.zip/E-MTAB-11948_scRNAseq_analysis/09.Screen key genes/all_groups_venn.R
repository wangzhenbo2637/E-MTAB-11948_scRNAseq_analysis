#!/usr/bin/Rscript
# _*_ coding: utf-8 _*_

library(VennDiagram)
library(ggplot2)
library(optparse)

#step1
option_list <- list(
	make_option(c("-i", "--input"), type = "character", default = FALSE, action = "store", help = "This is input file!"),
	make_option(c("-g", "--group"), type = "character", default = FALSE, action = "store", help = "This is group information!"),
	make_option(c("-o", "--outpath"), type = "character", default = FALSE, action = "store", help = "This is outpath!"))

#step2
opt_parse = OptionParser(usage = "usage: %prog [options]", option_list = option_list, add_help_option = TRUE, prog = NULL, description = "This Script is a Venn plot!")

#step3
opt = parse_args(opt_parse)

#step4
inputfile = opt$input
group = opt$group
outpath = opt$outpath

data <- read.table(file = inputfile, header = TRUE, sep = "\t", check.names = FALSE)
data <- na.omit(data)

clean_set <- function(x){
	x <- na.omit(x)
	x <- x[x != ""]
	unique(x)
}

draw_pairwise_venn <- function(dataset){
	set1 <- clean_set(dataset[,1])
	set2 <- clean_set(dataset[,2])
	groups <- colnames(dataset)
	draw.pairwise.venn(
		area1 = length(set1),
		area2 = length(set2),
		cross.area = length(intersect(set1, set2)),
		category = groups,
		fill = c("lightgreen", "lightblue"),
		alpha = 0.5,
		lty = "blank",
		cex = 3.0,
		cat.cex = 3.0,
		cat.fontface = "bold",
		cat.pos = c(-40, 40),
		cat.dist = 0.05,
		ind = TRUE,
		scaled = F )
}

draw_triple_venn <- function(dataset){
	set1 <- clean_set(dataset[,1])
	set2 <- clean_set(dataset[,2])
	set3 <- clean_set(dataset[,3])
	groups <- colnames(dataset)
	draw.triple.venn(
		area1 = length(set1),
		area2 = length(set2),
		area3 = length(set3),
		n12 = length(intersect(set1, set2)),
		n13 = length(intersect(set1, set3)),
		n23 = length(intersect(set2, set3)),
		n123 = length(Reduce(intersect, list(set1, set2, set3))),
		category = groups,
		fill = c("#9DAAA3", "#E9EBEA", "#FDE0A4"),
		alpha = 0.5,
		lty = "blank",
		cex = 3.0,
		cat.cex = 3.0,
		cat.fontface = "bold")
}

draw_quad_venn <- function(dataset){
	set1 <- clean_set(dataset[,1])
	set2 <- clean_set(dataset[,2])
	set3 <- clean_set(dataset[,3])
	set4 <- clean_set(dataset[,4])
	groups <- colnames(dataset)
	draw.quad.venn(
		area1 = length(set1),
		area2 = length(set2),
		area3 = length(set3),
		area4 = length(set4),
		n12   = length(intersect(set1, set2)),
		n13   = length(intersect(set1, set3)),
		n14   = length(intersect(set1, set4)),
		n23   = length(intersect(set2, set3)),
		n24   = length(intersect(set2, set4)),
		n34   = length(intersect(set3, set4)),
		n123  = length(Reduce(intersect, list(set1, set2, set3))),
		n124  = length(Reduce(intersect, list(set1, set2, set4))),
		n134  = length(Reduce(intersect, list(set1, set3, set4))),
 		n234  = length(Reduce(intersect, list(set2, set3, set4))),
		n1234 = length(Reduce(intersect, list(set1, set2, set3, set4))),
		category = groups,
		fill = c("#9EA89E", "#E8E9E8", "#DBD1C4", "#FFE1A5"),
		alpha = 0.5, 
		lty = "blank",
		cex = 1.3,
		cat.cex = 1.3,
		cat.fontface = "bold")
}

draw_quintuple_venn <- function(dataset){
	set1 <- clean_set(dataset[,1])
	set2 <- clean_set(dataset[,2])
	set3 <- clean_set(dataset[,3])
	set4 <- clean_set(dataset[,4])
	set5 <- clean_set(dataset[,5])
	groups <- colnames(dataset)
	n12 <- length(intersect(set1, set2))
	n13 <- length(intersect(set1, set3))
	n14 <- length(intersect(set1, set4))
	n15 <- length(intersect(set1, set5))
	n23 <- length(intersect(set2, set3))
	n24 <- length(intersect(set2, set4))
	n25 <- length(intersect(set2, set5))
	n34 <- length(intersect(set3, set4))
	n35 <- length(intersect(set3, set5))
	n45 <- length(intersect(set4, set5))
	n123 <- length(Reduce(intersect, list(set1, set2, set3)))
	n124 <- length(Reduce(intersect, list(set1, set2, set4)))
	n125 <- length(Reduce(intersect, list(set1, set2, set5)))
	n134 <- length(Reduce(intersect, list(set1, set3, set4)))
	n135 <- length(Reduce(intersect, list(set1, set3, set5)))
	n145 <- length(Reduce(intersect, list(set1, set4, set5)))
	n234 <- length(Reduce(intersect, list(set2, set3, set4)))
	n235 <- length(Reduce(intersect, list(set2, set3, set5)))
	n245 <- length(Reduce(intersect, list(set2, set4, set5)))
	n345 <- length(Reduce(intersect, list(set3, set4, set5)))
	n1234 <- length(Reduce(intersect, list(set1, set2, set3, set4)))
	n1235 <- length(Reduce(intersect, list(set1, set2, set3, set5)))
	n1245 <- length(Reduce(intersect, list(set1, set2, set4, set5)))
	n1345 <- length(Reduce(intersect, list(set1, set3, set4, set5)))
	n2345 <- length(Reduce(intersect, list(set2, set3, set4, set5)))
	n12345 <- length(Reduce(intersect, list(set1, set2, set3, set4, set5)))
	draw.quintuple.venn(
		area1 = length(set1),
		area2 = length(set2),
		area3 = length(set3),
		area4 = length(set4),
		area5 = length(set5),
		n12 = n12, n13 = n13, n14 = n14, n15 = n15,
		n23 = n23, n24 = n24, n25 = n25,
		n34 = n34, n35 = n35, n45 = n45,
		n123 = n123, n124 = n124, n125 = n125,
		n134 = n134, n135 = n135, n145 = n145,
		n234 = n234, n235 = n235, n245 = n245,
		n345 = n345,
		n1234 = n1234, n1235 = n1235, n1245 = n1245,
		n1345 = n1345, n2345 = n2345,
		n12345 = n12345,
		category = groups,
		fill = c("#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2"),
		alpha = 0.5,
		lty = "blank",
		cex = 1.5,
		cat.cex = 1.5,
		cat.pos = c(0, 45, 135, 225, 315),
		cat.dist = c(0.25, 0.25, 0.25, 0.25, 0.25),
		cat.fontface = "bold",
		margin = 0.15,
		ind = TRUE,
	#	print.mode = "percent",
		sigdigs = 2)
}

n_col <- ncol(data)
if (n_col == 2){
	png(paste0(outpath, "pairwise_venn.png"), width = 1200, height = 1200, units = "px")
	draw_pairwise_venn(data)
	dev.off()
	pdf(paste0(outpath, "pairwise_venn.pdf"), width = 12, height = 12)
	draw_pairwise_venn(data)
	dev.off()
} else if (n_col == 3){
	png(paste0(outpath, "triple_venn.png"), width = 1200, height = 1200, units = "px")
	draw_triple_venn(data)
	dev.off()
	pdf(paste0(outpath, "triple_venn.pdf"), width = 12, height = 12)
	draw_triple_venn(data)
	dev.off()
} else if (n_col == 4){
	png(paste0(outpath, "quad_venn.png"), width = 1200, height = 1000, units = "px")
	draw_quad_venn(data)
	dev.off()
	pdf(paste0(outpath, "quad_venn.pdf"), width = 12, height = 10)
	draw_quad_venn(data)
	dev.off()
} else if (n_col == 5){
	png(paste0(outpath, "quintuple_venn.png"), width = 1200, height = 1000, units = "px")
	draw_quintuple_venn(data)
	dev.off()
	pdf(paste0(outpath, "quintuple_venn.pdf"), width = 12, height = 10)
	draw_quintuple_venn(data)
	dev.off()
} else {
	print ("group number > 5, please UpSetR plot UpSet picture!")
}