#!/usr/bin/Rscript
# _*_ coding: utf-8 _*_

library(optparse)
library(ggplot2)
library(stringr)
library(enrichplot)
library(clusterProfiler)
library(pathview)
library(riceidconverter)

#step1
option_list <- list(
        	make_option(c("-i", "--input"), type = "character", default = FALSE, action = "store", help = "This is input file!"),
	make_option(c("-d", "--OrgDb"), type = "character", default = FALSE, action = "store", help = "This is OrgDb species!"),
	make_option(c("-s", "--organism"), type = "character", default = FALSE, action = "store", help = "This is organism species!"),
	make_option(c("-g", "--genome"), type = "character", default = FALSE, action = "store", help = "This is Reference genome!"),
	make_option(c("-p", "--pvalue"), type = "double", default = FALSE, action = "store", help = "This is pvalue Cutoff"),
	make_option(c("-q", "--qvalue"), type = "double", default = FALSE, action = "store", help = "This is qvalue Cutoff"),
        	make_option(c("-o", "--outpath"), type = "character", default = FALSE, action = "store", help = "This is outpath!"))

#step2
opt_parse = OptionParser(usage = "usage: %prog [options]", option_list = option_list, add_help_option = TRUE, prog = NULL, description = "")

#step3
opt = parse_args(opt_parse)

#step4
inputfile = opt$input
outpath = opt$outpath
OrgDb_species = opt$OrgDb
organism_species = opt$organism
Reference_genome = opt$genome
pvalue = opt$pvalue
qvalue = opt$qvalue
library(OrgDb_species,character.only = TRUE)

data <- read.table(file = inputfile, header = TRUE, sep = "\t", check.names = FALSE)

GO_database <- OrgDb_species #http://bioconductor.org/packages/release/BiocViews.html#___OrgDb
KEGG_database <- organism_species #http://www.genome.jp/kegg/catalog/org_list.html

database_name = strsplit(Reference_genome, "_")
if (grepl(database_name[[1]], "Ensembl")){
	gene <<- bitr(data$Genename, fromType = 'ENSEMBL', toType = c('SYMBOL','ENTREZID'), OrgDb = GO_database)
#	names(data) <- c('ENSEMBL','Log2FoldChange')
	names(data) <- c('ENSEMBL')
	df_merge <- merge(data, gene, by = 'ENSEMBL')
}else{
	gene <<- bitr(data$Genename, fromType = 'SYMBOL', toType = 'ENTREZID', OrgDb = GO_database)
#	names(data) <- c('SYMBOL','Log2FoldChange')
	names(data) <- c('SYMBOL')
	df_merge <- merge(data, gene, by = 'SYMBOL')
}

#pathview_data <- df_merge$Log2FoldChange #numeric vector
#names(pathview_data) = as.character(df_merge$ENTREZID) #named vector
#pathview_data = sort(pathview_data, decreasing = TRUE)
#output_file <- file.path(outpath, "Gene_Symbol_Entrezid.xls")
#write.table(df_merge, output_file, sep = '\t', quote = FALSE, row.names = FALSE)

KEGG <- enrichKEGG(gene$ENTREZID,
	organism = KEGG_database,
	keyType = 'kegg',
	pAdjustMethod = "BH",
	pvalueCutoff = pvalue,
	qvalueCutoff = qvalue,
	minGSSize = 1,
	maxGSSize = 1000)

KEGG <- setReadable(KEGG, OrgDb = OrgDb_species, keyType = "ENTREZID")
if (organism_species == "mmu"){
	KEGG@result$Description = gsub(" - Mus musculus \\(house mouse\\)", "", KEGG@result$Description)
}
kegg <- as.data.frame(KEGG)
#table(kegg[,1])

mytheme1 <- theme(axis.line = element_line(colour = "black"),
	axis.text = element_text(color = 'black'),
	panel.grid = element_line(color = 'grey'),
	panel.border = element_rect(fill = 'transparent',color = 'black'),
	panel.background = element_rect(fill = 'transparent', color = 'grey50'),
	plot.title = element_text(hjust = 0.5, size = 13),
	axis.text.x = element_text(size = 10),
	axis.text.y = element_text(size = 10),
	axis.title = element_text(size = 12),
	legend.title = element_text(size = 10),
	legend.text = element_text(size = 9))

mytheme2 <- theme(axis.line = element_line(colour = "black"),
	axis.text = element_text(color = 'black'),
	panel.grid = element_blank(),
	panel.border = element_rect(fill = 'transparent',color = 'black'),
	panel.background = element_rect(fill = 'transparent', color = 'grey50'),
	plot.title = element_text(hjust = 0.5, size = 13),
	axis.text.x = element_text(size = 10),
	axis.text.y = element_text(size = 10),
	axis.title = element_text(size = 12),
	axis.title.x = element_text(size = 12),
	axis.title.y = element_text(size = 12),
	legend.title = element_text(size = 10),
	legend.text = element_text(size = 9),
	legend.key.size = unit(0.4, units = "cm"))

KEGG_plot <- KEGG
KEGG_plot@result$GeneRatio <- sapply(KEGG_plot@result$GeneRatio, function(x){
	parts <- strsplit(x, "/")[[1]]
	as.numeric(parts[1]) / as.numeric(parts[2])
})

KEGG_Pathway_dotplot <- ggplot(KEGG_plot[1:20,], aes(x = GeneRatio, y = reorder(Description, p.adjust), size = Count, colour = p.adjust)) +
	geom_point() +
	scale_size_continuous(range = c(8, 15)) +
	labs(title = "Top 20 of KEGG Enrichment", x = "GeneRatio", y = "Pathway") +
	scale_color_gradient(low = "red", high = "green") +
	scale_y_discrete(labels = function(x) str_wrap(x, width = 60)) +
	mytheme1
output_file1 <- file.path(outpath, "KEGG_Pathway_dotplot.xls")
write.table(KEGG[1:20,], output_file1, sep = '\t', quote = FALSE, row.names = FALSE)

KEGG_Pathway_barplot <- ggplot(KEGG_plot[1:20,], aes(x = Count, y = reorder(Description, p.adjust), fill = p.adjust)) +
	geom_bar(stat = "identity") +
	geom_text(aes(label = Count), hjust = -0.2, size = 4) +
	labs(title = "Top 20 of KEGG Enrichment", x = "Count", y = "Pathway") +
	scale_fill_gradient(low = "#0895AF", high = "#9BD8CC") +
	scale_y_discrete(labels = function(x) str_wrap(x, width = 60)) +
	mytheme2
output_file2 <- file.path(outpath, "KEGG_Pathway_barplot.xls")
write.table(KEGG[1:20,], output_file2, sep = '\t', quote = FALSE, row.names = FALSE)

#KEGG_Pathway_cnetplot <- enrichplot::cnetplot(KEGG, circular = FALSE, colorEdge = TRUE) #circluar为指定是否环化，基因过多时建议设置为FALSE
#output_file3 <- file.path(outpath, "KEGG_Pathway_cnetplot.xls")
#write.table(KEGG, output_file3, sep = '\t', quote = FALSE, row.names = FALSE)

#KEGG2 <- pairwise_termsim(KEGG)
#KEGG_Pathway_emapplot <- enrichplot::emapplot(KEGG2, showCategory = 50, color = "p.adjust", layout = "kk")
#output_file4 <- file.path(outpath, "KEGG_Pathway_emapplot.txt")
#write.table(KEGG2, output_file4, sep = '\t', quote = FALSE, row.names = FALSE)

output_file5 <- file.path(outpath, "KEGG_Pathway_dotplot")
output_file6 <- file.path(outpath, "KEGG_Pathway_barplot")
#output_file7 <- file.path(outpath, "KEGG_Pathway_cnetplot")
#output_file8 <- file.path(outpath, "KEGG_Pathway_emapplot")

#print to png
png(paste0(output_file5, ".png"), width = 18, height = 20, units = "in", res = 300)
KEGG_Pathway_dotplot
dev.off()
ggsave(paste0(output_file6, ".png"), plot = KEGG_Pathway_barplot, width = 200, height = 150, units = "mm", dpi = 300)
#png(paste0(output_file6, ".png"), width = 18, height = 20, units = "in", res = 300)
#KEGG_Pathway_barplot
#dev.off()
#png(paste0(output_file7, ".png"), width = 15, height = 12, units = "in", res = 300)
#KEGG_Pathway_cnetplot
#dev.off()
#png(paste0(output_file8, ".png"), width = 15, height = 12, units = "in", res = 300)
#KEGG_Pathway_emapplot
#dev.off()

#print to pdf
pdf(paste0(output_file5, ".pdf"), width = 18, height = 20)
KEGG_Pathway_dotplot
dev.off()
ggsave(paste0(output_file6, ".pdf"), plot = KEGG_Pathway_barplot, width = 200, height = 150, units = "mm")
#pdf(paste0(output_file6, ".pdf"), width = 18, height = 20)
#KEGG_Pathway_barplot
#dev.off()
#pdf(paste0(output_file7, ".pdf"), width = 15, height = 12)
#KEGG_Pathway_cnetplot
#dev.off()
#pdf(paste0(output_file8, ".pdf"), width = 15, height = 12)
#KEGG_Pathway_emapplot
#dev.off()

output_file9 <- file.path(outpath, "KEGG_Pathway.xls")
#output_file10 <- file.path(outpath, "KEGG_IDs.txt")
write.table(kegg, output_file9, sep = '\t', quote = FALSE, row.names = FALSE)
#kegg_url <- paste("www.kegg.jp/kegg-bin/show_pathway?", KEGG$ID, sep = "")
#write.table(kegg_url,file=output_file10,append=FALSE,quote=TRUE,sep="\t",eol="\n",na="NA",dec=".",row.names=TRUE,col.names=TRUE,qmethod=c("escape","double"),fileEncoding="")

#browseKEGG(KEGG,"mmu04666")
#for (keggid in KEGG$ID){
#	pathway <- paste(outpath, "pathway", keggid, sep = "/")
#	if (!dir.exists(pathway)){
#		dir.create(pathway)
#	}
#	setwd(pathway)
#	keggid <- tryCatch({
#		pathview(gene.data = pathview_data, pathway.id = keggid, species = organism_species, limit = list(gene = c(-8,8)),
#		low = list(gene = "#00ff00"), mid = list(gene = "#acacac"), high = list(gene = "#ff0000"))
#	}, error = function(e){
#		print(e)
#	}, finally = {
#		print(paste(keggid, "complete"))
#	})
#}